################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/proj_mp/ee4u_half_precision_ieee754_base_n_soln/soln/ee4u_half_precision_ieee754_fns_soln.c 

OBJS += \
./soln/ee4u_half_precision_ieee754_fns_soln.o 

C_DEPS += \
./soln/ee4u_half_precision_ieee754_fns_soln.d 


# Each subdirectory must supply rules for building sources it contributes
soln/ee4u_half_precision_ieee754_fns_soln.o: C:/proj_mp/ee4u_half_precision_ieee754_base_n_soln/soln/ee4u_half_precision_ieee754_fns_soln.c soln/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-soln

clean-soln:
	-$(RM) ./soln/ee4u_half_precision_ieee754_fns_soln.cyclo ./soln/ee4u_half_precision_ieee754_fns_soln.d ./soln/ee4u_half_precision_ieee754_fns_soln.o ./soln/ee4u_half_precision_ieee754_fns_soln.su

.PHONY: clean-soln

