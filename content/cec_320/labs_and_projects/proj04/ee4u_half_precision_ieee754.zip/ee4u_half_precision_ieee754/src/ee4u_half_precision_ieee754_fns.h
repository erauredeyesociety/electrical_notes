#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include <math.h>

typedef struct {
    uint8_t  sign;        // Sign of a half-precision IEEE 754 number
    uint8_t  exponent;    // Exponent of a half-precision IEEE 754 number
    uint16_t fraction;    // Fraction of a half-precision IEEE 754 number
} hp_IEEE754Field_TypeDef;

void mp_hp_ieee754_encoding(float f, hp_IEEE754Field_TypeDef *pField);
float mp_hp_ieee754_decoding(hp_IEEE754Field_TypeDef field);

#ifdef __cplusplus
}
#endif /* __cplusplus */
