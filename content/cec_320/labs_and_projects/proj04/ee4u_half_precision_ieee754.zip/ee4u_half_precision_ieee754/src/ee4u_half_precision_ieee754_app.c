#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "ee4u_half_precision_ieee754_fns.h"

hp_IEEE754Field_TypeDef hp_fields[3];

void mp_app(void) {
    printf("\n\nee4u Half Precision IEEE 754 App-----------\n");

    float a_too_big_num = pow(2.0, 18);
    float a_normal_num = -31.875;
    float a_tiny_num = pow(2.0, -18);

// Convert the value of a float number to its field expression
    mp_hp_ieee754_encoding(a_too_big_num, &hp_fields[0]);
    mp_hp_ieee754_encoding(a_normal_num, &hp_fields[1]);
    mp_hp_ieee754_encoding(a_tiny_num, &hp_fields[2]);

    printf("Sign = %1d, Expt = %3d, Frac = 0x%06X\n", hp_fields[0].sign,
        hp_fields[0].exponent, hp_fields[0].fraction);
    printf("Sign = %1d, Expt = %3d, Frac = 0x%06X\n", hp_fields[1].sign,
        hp_fields[1].exponent, hp_fields[1].fraction);
    printf("Sign = %1d, Expt = %3d, Frac = 0x%06X\n", hp_fields[2].sign,
        hp_fields[2].exponent, hp_fields[2].fraction);

// Convert the field expression of a number to its value
    float reconstructed1 = mp_hp_ieee754_decoding(hp_fields[1]);
    float reconstructed2 = mp_hp_ieee754_decoding(hp_fields[2]);

    printf("Value = %f\n", reconstructed1);
    printf("Value = %f\n", reconstructed2*pow(2.0, 18));

    while(1);
}
