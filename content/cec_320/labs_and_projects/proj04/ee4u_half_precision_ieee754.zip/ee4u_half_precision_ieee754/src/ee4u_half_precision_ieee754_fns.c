#include "ee4u_half_precision_ieee754_fns.h"

/*
We assume the half-precision IEEE 754 numbers conform to the
IEEE 754-2008 standard. They have the following fields:
-   sign: 1 bit
-   exponent: 5 bits
-   fraction: 10 bits
*/

#define n_expt 5                        // 5 bits for exponent
#define n_frac 10                       // 10 bits for fraction
#define bias ((1 << (n_expt-1)) -1)     // Bias = 2^(n_expt-1) - 1 = 15.


/*
Function for encoding a floating-point number using the half-precision
IEEE 754 format.

Input:
-   f: the real number.
-   pField: pointer to the data structure representing the 3 fields of
            the encoding.

Return: No. Values changed in fields already.
*/
__attribute__((weak))
void mp_hp_ieee754_encoding(float f, hp_IEEE754Field_TypeDef *pField) {
    // f is a hp float, but we use a float type to keep the precision.

    // The maximum number for hp_float:
    // (1 + (1 - 2^(-n_frac))) * 2^(bias) =
    // (1 + (1 - 2^(-10))) * 2^(15) = 2^16 - 2^5.
    const double hp_float_max = pow(2.0, bias+1) - pow(2.0, bias-n_frac);
    // The minimum normalized number for hp_float:
    // 1.0 * 2^(1-bias) = 1.0 * 2^(1 - 15) = 2^(-14).
    const double hp_float_min_norm = pow(2.0, (1-bias));

    // Determine pField->sign

    // The following will be executed only if f is not bigger than the max.
    // Determine pField->exponent

    // Determine ppField->fraction

    return;
}

/*
Function for decoding a floating-point number using the half-precision
IEEE 754 format.

Input:
-   field: a data structure representing the 3 fields of the encoding.

Return:
-   f: the real number.
*/
__attribute__((weak))
float mp_hp_ieee754_decoding(hp_IEEE754Field_TypeDef field) {
    float decoded = 0.0;
    return decoded;
}
