#include "unity.h"
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "ee4u_half_precision_ieee754_fns.h"

void test_mp_hp_ieee754_encoding_a_too_big_num(void) {
    hp_IEEE754Field_TypeDef hp_fields;

    float a_too_big_num = pow(2.0, 18);
    uint16_t a_too_big_num_exp[] = {0, 31, 0};

    mp_hp_ieee754_encoding(a_too_big_num, &hp_fields);

    uint16_t a_too_big_num_act[3];

    a_too_big_num_act[0] = hp_fields.sign;
    a_too_big_num_act[1] = hp_fields.exponent;
    a_too_big_num_act[2] = hp_fields.fraction;

    TEST_ASSERT_EQUAL_UINT16_ARRAY(a_too_big_num_exp, a_too_big_num_act, 3);
}

void test_mp_hp_ieee754_encoding_a_normal_num(void) {
    hp_IEEE754Field_TypeDef hp_fields;

    float a_normal_num = -31.875;
    uint16_t a_normal_num_exp[] = {1, 19, 0x3F8};

    mp_hp_ieee754_encoding(a_normal_num, &hp_fields);

    uint16_t a_normal_num_act[3];

    a_normal_num_act[0] = hp_fields.sign;
    a_normal_num_act[1] = hp_fields.exponent;
    a_normal_num_act[2] = hp_fields.fraction;

    TEST_ASSERT_EQUAL_UINT16_ARRAY(a_normal_num_exp, a_normal_num_act, 3);
}

void test_mp_hp_ieee754_encoding_a_tiny_num(void) {
    hp_IEEE754Field_TypeDef hp_fields;

    float a_tiny_num = pow(2.0, -18);
    uint16_t a_tiny_num_exp[] = {0, 0, 0x40};

    mp_hp_ieee754_encoding(a_tiny_num, &hp_fields);

    uint16_t a_tiny_num_act[3];

    a_tiny_num_act[0] = hp_fields.sign;
    a_tiny_num_act[1] = hp_fields.exponent;
    a_tiny_num_act[2] = hp_fields.fraction;

    TEST_ASSERT_EQUAL_UINT16_ARRAY(a_tiny_num_exp, a_tiny_num_act, 3);
}

void test_mp_hp_ieee754_decoding_a_normal_num(void) {
    hp_IEEE754Field_TypeDef hp_fields;
    float a_normal_num_exp = -31.875;
    uint16_t a_normal_num_elements[] = {1, 19, 0x3F8};

    hp_fields.sign     = a_normal_num_elements[0];
    hp_fields.exponent = a_normal_num_elements[1];
    hp_fields.fraction = a_normal_num_elements[2];

    float a_normal_num_act = mp_hp_ieee754_decoding(hp_fields);

    TEST_ASSERT_EQUAL_FLOAT(a_normal_num_exp, a_normal_num_act);
}

void test_mp_hp_ieee754_decoding_a_tiny_num(void) {
    hp_IEEE754Field_TypeDef hp_fields;
    float a_tiny_num_exp = pow(2.0, -18);
    uint16_t a_tiny_num_elements[] = {0, 0, 0x40};

    hp_fields.sign     = a_tiny_num_elements[0];
    hp_fields.exponent = a_tiny_num_elements[1];
    hp_fields.fraction = a_tiny_num_elements[2];

    float a_tiny_num_act = mp_hp_ieee754_decoding(hp_fields);

    TEST_ASSERT_EQUAL_FLOAT(a_tiny_num_exp, a_tiny_num_act);
}

int mp_unity(void) {
    printf("\nee4u Half Precision IEEE754 unit test starts here:---\n\n");

    UNITY_BEGIN();

    RUN_TEST(test_mp_hp_ieee754_encoding_a_too_big_num);
    RUN_TEST(test_mp_hp_ieee754_encoding_a_normal_num);
    RUN_TEST(test_mp_hp_ieee754_encoding_a_tiny_num);
    RUN_TEST(test_mp_hp_ieee754_decoding_a_normal_num);
    RUN_TEST(test_mp_hp_ieee754_decoding_a_tiny_num);

    UNITY_END();

    while(1);
}
