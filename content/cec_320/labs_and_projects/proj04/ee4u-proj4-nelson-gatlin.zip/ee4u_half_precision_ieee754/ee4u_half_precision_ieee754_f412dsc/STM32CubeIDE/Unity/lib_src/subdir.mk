################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/opt/proj_mp/ee4u_half_precision_ieee754/src/_mp_main.c \
/opt/proj_mp/ee4u_half_precision_ieee754/src/ee4u_half_precision_ieee754_app.c \
/opt/proj_mp/ee4u_half_precision_ieee754/src/ee4u_half_precision_ieee754_fns.c \
/opt/proj_mp/ee4u_half_precision_ieee754/lib/mp_uart_redirect.c \
/opt/proj_mp/ee4u_half_precision_ieee754/test/test_ee4u_half_precision_ieee754.c \
/opt/proj_mp/ee4u_half_precision_ieee754/lib/unity.c 

OBJS += \
./lib_src/_mp_main.o \
./lib_src/ee4u_half_precision_ieee754_app.o \
./lib_src/ee4u_half_precision_ieee754_fns.o \
./lib_src/mp_uart_redirect.o \
./lib_src/test_ee4u_half_precision_ieee754.o \
./lib_src/unity.o 

C_DEPS += \
./lib_src/_mp_main.d \
./lib_src/ee4u_half_precision_ieee754_app.d \
./lib_src/ee4u_half_precision_ieee754_fns.d \
./lib_src/mp_uart_redirect.d \
./lib_src/test_ee4u_half_precision_ieee754.d \
./lib_src/unity.d 


# Each subdirectory must supply rules for building sources it contributes
lib_src/_mp_main.o: /opt/proj_mp/ee4u_half_precision_ieee754/src/_mp_main.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/ee4u_half_precision_ieee754_app.o: /opt/proj_mp/ee4u_half_precision_ieee754/src/ee4u_half_precision_ieee754_app.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/ee4u_half_precision_ieee754_fns.o: /opt/proj_mp/ee4u_half_precision_ieee754/src/ee4u_half_precision_ieee754_fns.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/mp_uart_redirect.o: /opt/proj_mp/ee4u_half_precision_ieee754/lib/mp_uart_redirect.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/test_ee4u_half_precision_ieee754.o: /opt/proj_mp/ee4u_half_precision_ieee754/test/test_ee4u_half_precision_ieee754.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/unity.o: /opt/proj_mp/ee4u_half_precision_ieee754/lib/unity.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lib_src

clean-lib_src:
	-$(RM) ./lib_src/_mp_main.cyclo ./lib_src/_mp_main.d ./lib_src/_mp_main.o ./lib_src/_mp_main.su ./lib_src/ee4u_half_precision_ieee754_app.cyclo ./lib_src/ee4u_half_precision_ieee754_app.d ./lib_src/ee4u_half_precision_ieee754_app.o ./lib_src/ee4u_half_precision_ieee754_app.su ./lib_src/ee4u_half_precision_ieee754_fns.cyclo ./lib_src/ee4u_half_precision_ieee754_fns.d ./lib_src/ee4u_half_precision_ieee754_fns.o ./lib_src/ee4u_half_precision_ieee754_fns.su ./lib_src/mp_uart_redirect.cyclo ./lib_src/mp_uart_redirect.d ./lib_src/mp_uart_redirect.o ./lib_src/mp_uart_redirect.su ./lib_src/test_ee4u_half_precision_ieee754.cyclo ./lib_src/test_ee4u_half_precision_ieee754.d ./lib_src/test_ee4u_half_precision_ieee754.o ./lib_src/test_ee4u_half_precision_ieee754.su ./lib_src/unity.cyclo ./lib_src/unity.d ./lib_src/unity.o ./lib_src/unity.su

.PHONY: clean-lib_src

