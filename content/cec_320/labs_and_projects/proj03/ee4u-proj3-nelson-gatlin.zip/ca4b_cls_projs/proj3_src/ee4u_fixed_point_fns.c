#include "ee4u_fixed_point_fns.h"

/*
Function for UQm.n and Qm.n decoding. Given the coded data D and the number
    of bits for each field, determine the real number f.

Input:
-   D: encoded data.
-   s: type of representation: 1 for Qm.n (signed); 0 for UQm.n.
-   m: number of bits in the whole number field.
-   n: number of bits in the fraction field.

Return:
-   f: the real number.
*/

float mp_uq_and_q_mn_decoding(uint32_t D, int s, int m, int n) {
    int total_bits = m + n + s;  // s=1 adds sign bit for Qm.n
    uint32_t mask = (1U << total_bits) - 1;
    D = D & mask;  // mask to relevant bits

    float f;
    if (s && (D >> (total_bits - 1))) {
        // Signed Qm.n and sign bit is set: negative number
        // Sign-extend and convert via two's complement
        int32_t signed_D = (int32_t)(D | (~mask));
        f = (float)signed_D / (float)(1 << n);
    } else {
        // Unsigned UQm.n or positive Qm.n
        f = (float)D / (float)(1 << n);
    }
    return f;
}

/*
Function for UQm.n and Qm.n encoding. Given the real number f and the number
    of bits for each field, determine the real number f.

Input:
-   f: real number to be encoded.
-   s: type of representation: 1 for Qm.n (signed); 0 for UQm.n.
-   m: number of bits in the whole number field.
-   n: number of bits in the fraction field.

Return:
-   D: the encoded data.
*/

uint32_t mp_uq_and_q_mn_encoding(float f, int s, int m, int n) {
    float fn = f * (1 << n);
    int32_t intD = lrint(fn);
    uint32_t D = (uint32_t)intD;
    return D;
}

/*
Function for Qm.n multiplication. Given real numbers f1 and f1 and
    the number of bits for each field, determine the product of f1 and f2.
    Note that we only handle Qm.n, not UQm.n

Input:
-   f1: real number used as operand 1.
-   f2: real number used as operand 2.
-   m: number of bits in the whole number section.
-   n: number of bits in the fraction section.

Return:
-   p: the product of f1 * f2 using Qm.n multiplication.
*/

float mp_q_mn_multiplication(float f1, float f2, int m, int n) {
    // Encode both operands to Qm.n (signed)
    int I1 = (int) mp_uq_and_q_mn_encoding(f1, 1, m, n);
    int I2 = (int) mp_uq_and_q_mn_encoding(f2, 1, m, n);
    // Multiply fixed-point values and shift right by n
    int I3 = I1 * I2;
    I3 >>= n;
    // Decode result back to float
    float prod = mp_uq_and_q_mn_decoding(I3, 1, m, n);
    return prod;
}
