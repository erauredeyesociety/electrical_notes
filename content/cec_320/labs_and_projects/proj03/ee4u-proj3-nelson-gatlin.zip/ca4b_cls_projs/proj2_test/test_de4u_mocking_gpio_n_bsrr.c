#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "unity.h"
#include "mp_stm32xx_mocked_gpiox.h"
#include "mp_mock_utils_4_gpio_regs.h"
#include "mp_mock_odr_update_with_bsrr_brr.h"
#include "mp_gpio_toggle.h"

//-----------------------------------------------
void test_read_idr_via_hal_func(void) {
    uint16_t act = 0, exp = 0xABCD;
    mp_mock_write_idr(GPIOx, exp);  // write to IDR as needed for testing
    uint16_t pin_state;
    for (int i = 0; i < 16; i++) {
        pin_state = HAL_GPIO_ReadPin(GPIOx, (1U<<i)); // read a pin
        act |= pin_state << i;
    }
    TEST_ASSERT_EQUAL_UINT16(exp, act);
}

//-----------------------------------------------
void test_read_idr_directly(void) {
    uint32_t act, exp = 0xABCD;
    mp_mock_write_idr(GPIOx, exp);  // write to IDR as needed for testing
    act = GPIOx->IDR;               // read IDR as normal
    TEST_ASSERT_EQUAL_UINT32(exp, act);
}

//-----------------------------------------------
void test_write_odr_via_hal_func(void) {
    uint32_t act, exp = 0xABCD;
    GPIOx->ODR = 0;                 // Clear ODR
    HAL_GPIO_WritePin(GPIOx, exp, GPIO_PIN_SET);  // Write to ODR as normal
    // The WritePin function only writes to BSRR; we need to update ODR
    mp_mock_odr_update_with_bsrr(GPIOx);
    act = mp_mock_read_odr(GPIOx);  // read from ODR as needed for testing
    TEST_ASSERT_EQUAL_UINT32(exp, act);
}

//-----------------------------------------------
void test_write_odr_directly(void) {
    uint32_t act, exp = 0xABCD;
    GPIOx->ODR = exp;               // Write to ODR as normal
    act = mp_mock_read_odr(GPIOx);  // read from ODR as needed for testing
    TEST_ASSERT_EQUAL_UINT32(exp, act);
}

//-----------------------------------------------
void test_write_bsrr_to_set_odr(void) {
    uint32_t exp = 0xABCD;
    uint32_t act;

    GPIOx->ODR = exp;
    // Wirte to lower halfword to set ODR
    GPIOx->BSRR = 0x1234;
    mp_mock_odr_update_with_bsrr(GPIOx);
    act = mp_mock_read_odr(GPIOx);
    // Expected value of ODR should be exp | 0x1234 now.
    TEST_ASSERT_EQUAL_UINT32(exp|0x1234, act);

    GPIOx->ODR = exp;
    // Now, check if the BSRR is cleared to 0 or not.
    mp_mock_odr_update_with_bsrr(GPIOx);
    act = mp_mock_read_odr(GPIOx);
    TEST_ASSERT_EQUAL_UINT32(exp, act);
}

//-----------------------------------------------
void test_write_bsrr_to_clear_odr(void) {
    uint32_t exp = 0xABCD;
    uint32_t act;

    GPIOx->ODR = exp;
    // Wirte to upper halfword to clear ODR
    GPIOx->BSRR = 0x1234 << 16;
    mp_mock_odr_update_with_bsrr(GPIOx);
    act = mp_mock_read_odr(GPIOx);
    // Expected value of ODR should be exp & ~0x1234 now.
    TEST_ASSERT_EQUAL_UINT32(exp & (~0x1234), act);

    GPIOx->ODR = exp;
    // Now, check if the BSRR is cleared to 0 or not.
    mp_mock_odr_update_with_bsrr(GPIOx);
    act = mp_mock_read_odr(GPIOx);
    TEST_ASSERT_EQUAL_UINT32(exp, act);
}

//-----------------------------------------------
void test_hal_gpio_toggle_pin_via_hal_func(void) {
	// Here we test the toggle of Pins 4 to 7.
    uint32_t act, exp = 0xABCD, odr = 0xAB3D;
    GPIOx->ODR = odr;               		// Write to ODR as normal
    HAL_GPIO_TogglePin(GPIOx, (15U<<4)); 	// toggle Pins 4 to 7.
    mp_mock_odr_update_with_bsrr(GPIOx);
    act = mp_mock_read_odr(GPIOx);     // read from ODR as needed for testing
    TEST_ASSERT_EQUAL_UINT32(exp, act);
}

void test_mp_gpio_toggle_pins_func(void) {
    uint32_t act, exp = 0xABCD, odr = 0xAB3D;
    GPIOx->ODR = odr;
    mp_GPIO_TogglePinS(GPIOx, (15U<<4));
    act = mp_mock_read_odr(GPIOx);
    TEST_ASSERT_EQUAL_UINT32(exp, act);
}

void mp_unity(void) {
    UNITY_BEGIN();

    RUN_TEST(test_read_idr_via_hal_func);
    RUN_TEST(test_read_idr_directly);
    RUN_TEST(test_write_odr_via_hal_func);
    RUN_TEST(test_write_odr_directly);
    RUN_TEST(test_write_bsrr_to_set_odr);
    RUN_TEST(test_write_bsrr_to_clear_odr);
    RUN_TEST(test_hal_gpio_toggle_pin_via_hal_func);
    RUN_TEST(test_mp_gpio_toggle_pins_func);

    UNITY_END();

    while (1);
}
