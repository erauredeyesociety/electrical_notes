#include "mp_supported_mcu.h"

GPIO_TypeDef mp_mocked_gpiox;

GPIO_TypeDef *GPIOx = &mp_mocked_gpiox;
