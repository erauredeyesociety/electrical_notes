#include "mp_supported_mcu.h"

void mp_GPIO_TogglePinS(GPIO_TypeDef* GPIOx, uint16_t GPIO_PinS) {
    /* Check the parameters */
    assert_param(IS_GPIO_PIN(GPIO_PinS));

    /* Toggle the pins using the bit mask GPIO_Pins */
    GPIOx->ODR ^= GPIO_PinS;
}
