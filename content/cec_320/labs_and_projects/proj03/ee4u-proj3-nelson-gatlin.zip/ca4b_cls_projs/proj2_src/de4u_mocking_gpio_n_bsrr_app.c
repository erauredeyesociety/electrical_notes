#include <stdlib.h>
#include <string.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"

void mp_app(void) {
    printf("\n\nRunning de4u App-----------------\n");

    printf("No other code. This is the end of the App.\n");

    while (1);
}
