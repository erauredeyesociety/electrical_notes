#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include "mp_supported_mcu.h"

void mp_mock_write_idr(GPIO_TypeDef *GPIOx, uint32_t idr);

uint32_t mp_mock_read_odr(GPIO_TypeDef *GPIOx);

#ifdef __cplusplus
}
#endif /* __cplusplus */
