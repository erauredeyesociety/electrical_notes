#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include "mp_supported_mcu.h"

void mp_GPIO_TogglePinS(GPIO_TypeDef* GPIOx, uint16_t GPIO_PinS);

#ifdef __cplusplus
}
#endif /* __cplusplus */
