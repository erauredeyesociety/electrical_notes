#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "mp_supported_mcu.h"

void mp_mock_odr_update_with_bsrr(GPIO_TypeDef *GPIOx);
void mp_mock_odr_update_with_brr(GPIO_TypeDef *GPIOx);

#ifdef __cplusplus
}
#endif /* __cplusplus */
