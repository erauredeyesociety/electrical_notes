#include "mp_supported_mcu.h"

uint32_t mp_mock_read_odr(GPIO_TypeDef *GPIOx) {
    return GPIOx->ODR;
}

void mp_mock_write_idr(GPIO_TypeDef *GPIOx, uint32_t idr) {
    GPIOx->IDR = idr;
}
