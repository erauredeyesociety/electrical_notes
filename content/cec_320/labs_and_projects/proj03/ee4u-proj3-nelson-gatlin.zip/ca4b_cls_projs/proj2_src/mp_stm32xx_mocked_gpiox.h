#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "mp_supported_mcu.h"

extern GPIO_TypeDef *GPIOx;

#ifdef __cplusplus
}
#endif /* __cplusplus */
