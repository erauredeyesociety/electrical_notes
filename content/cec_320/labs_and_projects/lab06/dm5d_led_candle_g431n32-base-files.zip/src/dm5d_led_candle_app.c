#include "main.h"
#include "mp_simple_pwm_leds.h"
#include "dm5d_led_candle_fns.h"

uint8_t uart2_rxBuffer[10] = {0};

// The following values should be changed to look more realistic.
int CCR_vals[] = {45000, 3000, 2000, 1000};

candle_state_t candle_state = CANDLE_DIM;
bool is_rdm_candle = true;  // Candle can be random or deterministic

// State transition probability matrix
float trans_prob[4][4] = {
        {0.30, 0.25, 0.25, 0.20},
        {0.25, 0.30, 0.25, 0.20},
        {0.25, 0.25, 0.30, 0.20},
        {0.20, 0.25, 0.25, 0.30},
};

// Cumulative transition matrix. We use the random falling range
// to speed up the computation of state transitions.
int cumu_trans_matrix[4][4];

char command = 0;
bool has_new_command = true;

char *help_msg = "Input one of the following: \n"
        "    r: go to random mode\n"
        "    d: go to deterministic mode\n"
        "        1: LED very bright in deterministic mode\n"
        "        2: LED bright in deterministic mode\n"
        "        3: LED dim in deterministic mode\n"
        "        4: LED very dim in deterministic mode\n";

// Print help message as needed
/*  Global flag has_new_command will be cleared by the following two functions
    if everything is ok:
        update_det_candle_state();
        print_help_message_if_needed();
    If not not cleared, we see there is something wrong with the user input.
    So, we print out the help message.
*/
void print_help_message_if_needed(void) {
    if (!has_new_command) {
        return;
    }
    printf("%s\n", help_msg);
    has_new_command = false;
}

// Callback for UART
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    has_new_command = true;
    HAL_UART_Receive_IT(&huart2, uart2_rxBuffer, 1);
}

// PWM function
void mp_set_timer_compare(uint16_t CCR_value) {
    __HAL_TIM_SET_COMPARE(&HTIM_LED3, TIM_CHANNEL_LED3, CCR_value);
    __HAL_TIM_SET_COMPARE(&HTIM_LED4, TIM_CHANNEL_LED4, CCR_value);
}


// Main app function
void mp_app(void) {
    printf("\ndm5d App starts here:---\n\n");
    create_cumu_trans_matrix();
    HAL_UART_Receive_IT(&huart2, uart2_rxBuffer, 1);
    HAL_TIM_PWM_Start(&HTIM_LED4, TIM_CHANNEL_LED4);
    HAL_TIM_PWM_Start(&HTIM_LED3, TIM_CHANNEL_LED3);

    while (1) {
        NVIC_DisableIRQ(USART2_IRQn); // Guard the processing of has_new_command
        update_candle_type();
        update_det_candle_state();
        print_help_message_if_needed();
        NVIC_EnableIRQ(USART2_IRQn);  // Guard the processing of has_new_command

        update_random_candle_state();
        mp_set_timer_compare(CCR_vals[candle_state]);
    }
}
