#include "dm5d_led_candle_fns.h"

// All the global vars are defined in xx_app.c so that we can do the same
// declaration in the solution version of this file.

extern uint8_t uart2_rxBuffer[];

extern candle_state_t candle_state;
extern bool is_rdm_candle;  // Candle can be random or deterministic

// State transition probability matrix
extern float trans_prob[4][4];

// Cumulative transition matrix. We use the random falling range
// to speed up the computation of state transitions.
extern int cumu_trans_matrix[4][4];

extern char command;
extern bool has_new_command;

// PT1. Update type of candle: random or deterministic
__attribute__((weak))
void update_candle_type(void) {
    if (!has_new_command) {
        return;
    }
    // We will be here only if we receive a new command.
    // With this trick, we can reduce one level of code indentation below.
    command = uart2_rxBuffer[0];
    if (is_rdm_candle) {
        if (command == 'd') {
            /// change candle type and the new command flag.
        }
    } else {
        if (command == 'r') {
            /// change candle type and the new command flag.
        }
    }
    printf("Candle type is %s\n", is_rdm_candle? "Random":"Deterministic");
}


// PT2. Update the deterministic candle state
__attribute__((weak))
void update_det_candle_state(void) {
    if (!has_new_command || is_rdm_candle) {
        return;
    }
    // Update the new deterministic candle state
    command = uart2_rxBuffer[0];
    if (command >= '1' && command <= '4') {
        /// change candle state and the new command flag.
    }
    printf("Candle state is %d\n", candle_state+1);
}


// PT3. Create the cumulative transition matrix from the
// state transition probability matrix.
__attribute__((weak))
void create_cumu_trans_matrix(void) {
    for (int i = 0; i < 4; i++) {
        float F = 0.0;   // Cumulative prob distribution
        for (int j = 0; j < 4; j++) {
            /// Find F
            cumu_trans_matrix[i][j] = lrint(F * STATE_TRANS_RANGE);
            printf("\t%d, ", cumu_trans_matrix[i][j]);
        }
        printf("\n");
    }
}


// PT4. LED candle state machine
__attribute__((weak))
void update_random_candle_state(void) {
    if (!is_rdm_candle) {
        return;
    }
    int random_choice = rand() % STATE_TRANS_RANGE;
    if (random_choice < cumu_trans_matrix[candle_state][0]) {
        candle_state = CANDLE_VERY_BRIGHT;
    } else if (random_choice < cumu_trans_matrix[candle_state][1]) {
        candle_state = CANDLE_BRIGHT;
    } else if (random_choice < cumu_trans_matrix[candle_state][2]) {
        candle_state = CANDLE_DIM;
    } else {
        candle_state = CANDLE_VERY_DIM;
    }

    HAL_Delay(DWELL_TIM_MIN);
}
