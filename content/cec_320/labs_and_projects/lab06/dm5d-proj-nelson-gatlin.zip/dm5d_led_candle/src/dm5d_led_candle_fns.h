#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include "mp_uart_redirect.h"


typedef enum {
    CANDLE_VERY_BRIGHT,
    CANDLE_BRIGHT,
    CANDLE_DIM,
    CANDLE_VERY_DIM,
} candle_state_t;

#define STATE_TRANS_RANGE 100

// Min and max dwell time on each state
#define DWELL_TIM_MIN 50
#define DWELL_TIM_MAX 150

void create_cumu_trans_matrix(void);
void update_candle_type(void);
void update_det_candle_state(void);
void update_random_candle_state(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */
