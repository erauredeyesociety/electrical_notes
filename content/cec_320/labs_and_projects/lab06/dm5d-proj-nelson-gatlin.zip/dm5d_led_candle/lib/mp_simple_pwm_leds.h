#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "mp_supported_mcu.h"

#if defined(STM32G431xx) 
    extern TIM_HandleTypeDef    htim2;
    #define HTIM_LED3           htim2
    #define TIM_CHANNEL_LED3    TIM_CHANNEL_2

    extern TIM_HandleTypeDef    htim4;
    #define HTIM_LED4           htim4
    #define TIM_CHANNEL_LED4    TIM_CHANNEL_3
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */
