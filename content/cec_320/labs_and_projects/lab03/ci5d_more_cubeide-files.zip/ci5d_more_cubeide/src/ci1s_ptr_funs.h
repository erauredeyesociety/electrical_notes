#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void mp_str2upper_dowhile(char *str);
void mp_strcpy(char *dst, char *src);

#ifdef __cplusplus
}
#endif /* __cplusplus */
