#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void mp_print_mcu_and_tool_info(void);
void mp_print_heap_n_stack_vars(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */
