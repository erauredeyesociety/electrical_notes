#include <stdlib.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"

void mp_print_mcu_and_tool_info(void) {

#if defined(STM32F412Zx)
    printf("MCU is STM32F412.\n");
#elif defined(STM32G431xx)
    printf("MCU is STM32G431.\n");
#elif defined(STM32L432xx)
    printf("MCU is STM32L432.\n");
#elif defined(STM32L476xx)
    printf("MCU is STM32L476.\n");
#else
    printf("Generic MCU.\n");
#endif

#if defined(CubeIDE)
    printf("Built by CubeIDE.\n\n");
#elif defined(Keil)
    printf("Built by Keil MDK.\n\n");
#else
    printf("Generic Toolchain.\n\n");
#endif

}

void mp_print_heap_n_stack_vars(void) {
    int stack_var = 0x12345678;
    printf("The approximate start address of stack is: %p\n", &stack_var);
    printf("The value of my local var is: 0x%08x\n\n", stack_var);

    int *heap_arr = (int *)malloc(16 * sizeof(int));
    printf("The approximate start address of heap is: %p\n\n", heap_arr);

    // Write numbers to the heap so that we can see them in Memory view
    for (int i = 0; i < 16; i++) {
        *(heap_arr + i) = stack_var >> i;
    }

    printf("Print selected values of the heap array. \n");
    for (int i = 0; i < 16; i += 4) {
        printf("0x%08x  ", *(heap_arr + i));
    }
    printf("\n\n");

    free(heap_arr);
}
