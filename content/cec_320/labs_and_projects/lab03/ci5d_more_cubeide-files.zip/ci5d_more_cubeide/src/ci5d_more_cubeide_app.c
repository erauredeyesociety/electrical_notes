#include <stdlib.h>
#include <string.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "ci1s_ptr_funs.h"
#include "ci5d_info_print_funs.h"

char message[] = "\n\nRunning ci5d: More CubeIDE Operations:---\n\n";
char *hello = "Hello world!\n";
void mp_app(void) {
    printf(message);

    mp_print_mcu_and_tool_info();
    mp_print_heap_n_stack_vars();

    mp_strcpy(message, hello);
    printf(message);

    while (1);
}
