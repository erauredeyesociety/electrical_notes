#include "ci1s_ptr_funs.h"

void mp_str2upper_dowhile(char *str) {
    char ch;
    do {
        ch = *str;
        if (ch >= 'a' && ch <= 'z') {
            *str -= 32; // Convert to upper case
        }
        str = str + 1;
    } while (ch);
}

void mp_strcpy(char *dst, char *src) {
    char ch;
    do {
        ch = *src++;
        *dst++ = ch;
    } while (ch);
}
