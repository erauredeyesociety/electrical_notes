@echo off

set PROJ=ci5d_more_cubeide

set BASE_PATH=C:\proj_mp
set PROJ_PATH=%BASE_PATH%\%PROJ%

echo Creating file structure for project %PROJ%:
echo.

mkdir "%PROJ_PATH%"
mklink /J "%PROJ_PATH%\lib" lib
mklink /J "%PROJ_PATH%\renode" renode
mklink /J "%PROJ_PATH%\src" src

mkdir "%PROJ_PATH%\%PROJ%_f412dsc"
mkdir "%PROJ_PATH%\%PROJ%_g431n32"
mklink /H "%PROJ_PATH%\%PROJ%_f412dsc\%PROJ%_f412dsc.ioc" %PROJ%_f412dsc\%PROJ%_f412dsc.ioc
mklink /H "%PROJ_PATH%\%PROJ%_g431n32\%PROJ%_g431n32.ioc" %PROJ%_g431n32\%PROJ%_g431n32.ioc

echo Project file structure created.
echo.
