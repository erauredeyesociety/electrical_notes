################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
C:/proj_mp/ge4a_load_n_store_base_n_soln/soln/ge4a_load_n_store_sfns.s 

OBJS += \
./soln/ge4a_load_n_store_sfns.o 

S_DEPS += \
./soln/ge4a_load_n_store_sfns.d 


# Each subdirectory must supply rules for building sources it contributes
soln/ge4a_load_n_store_sfns.o: C:/proj_mp/ge4a_load_n_store_base_n_soln/soln/ge4a_load_n_store_sfns.s soln/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-soln

clean-soln:
	-$(RM) ./soln/ge4a_load_n_store_sfns.d ./soln/ge4a_load_n_store_sfns.o

.PHONY: clean-soln

