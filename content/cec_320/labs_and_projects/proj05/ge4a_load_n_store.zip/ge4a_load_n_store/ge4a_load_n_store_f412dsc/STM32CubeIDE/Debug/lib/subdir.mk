################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/proj_mp/ge4a_load_n_store/lib/mp_uart_redirect.c \
C:/proj_mp/ge4a_load_n_store/lib/unity.c 

OBJS += \
./lib/mp_uart_redirect.o \
./lib/unity.o 

C_DEPS += \
./lib/mp_uart_redirect.d \
./lib/unity.d 


# Each subdirectory must supply rules for building sources it contributes
lib/mp_uart_redirect.o: C:/proj_mp/ge4a_load_n_store/lib/mp_uart_redirect.c lib/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_ge4a_load_n_store -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib/unity.o: C:/proj_mp/ge4a_load_n_store/lib/unity.c lib/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_ge4a_load_n_store -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lib

clean-lib:
	-$(RM) ./lib/mp_uart_redirect.cyclo ./lib/mp_uart_redirect.d ./lib/mp_uart_redirect.o ./lib/mp_uart_redirect.su ./lib/unity.cyclo ./lib/unity.d ./lib/unity.o ./lib/unity.su

.PHONY: clean-lib

