################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
C:/proj_mp/ge4a_load_n_store/src_ge4a_load_n_store/ge4a_load_n_store_sfns.s 

C_SRCS += \
C:/proj_mp/ge4a_load_n_store/src_ge4a_load_n_store/_ge4a_load_n_store_main.c \
C:/proj_mp/ge4a_load_n_store/src_ge4a_load_n_store/ge4a_load_n_store_app.c \
C:/proj_mp/ge4a_load_n_store/src_ge4a_load_n_store/ge4a_load_n_store_cfns.c 

OBJS += \
./src/_ge4a_load_n_store_main.o \
./src/ge4a_load_n_store_app.o \
./src/ge4a_load_n_store_cfns.o \
./src/ge4a_load_n_store_sfns.o 

S_DEPS += \
./src/ge4a_load_n_store_sfns.d 

C_DEPS += \
./src/_ge4a_load_n_store_main.d \
./src/ge4a_load_n_store_app.d \
./src/ge4a_load_n_store_cfns.d 


# Each subdirectory must supply rules for building sources it contributes
src/_ge4a_load_n_store_main.o: C:/proj_mp/ge4a_load_n_store/src_ge4a_load_n_store/_ge4a_load_n_store_main.c src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_ge4a_load_n_store -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
src/ge4a_load_n_store_app.o: C:/proj_mp/ge4a_load_n_store/src_ge4a_load_n_store/ge4a_load_n_store_app.c src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_ge4a_load_n_store -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
src/ge4a_load_n_store_cfns.o: C:/proj_mp/ge4a_load_n_store/src_ge4a_load_n_store/ge4a_load_n_store_cfns.c src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_ge4a_load_n_store -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
src/ge4a_load_n_store_sfns.o: C:/proj_mp/ge4a_load_n_store/src_ge4a_load_n_store/ge4a_load_n_store_sfns.s src/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-src

clean-src:
	-$(RM) ./src/_ge4a_load_n_store_main.cyclo ./src/_ge4a_load_n_store_main.d ./src/_ge4a_load_n_store_main.o ./src/_ge4a_load_n_store_main.su ./src/ge4a_load_n_store_app.cyclo ./src/ge4a_load_n_store_app.d ./src/ge4a_load_n_store_app.o ./src/ge4a_load_n_store_app.su ./src/ge4a_load_n_store_cfns.cyclo ./src/ge4a_load_n_store_cfns.d ./src/ge4a_load_n_store_cfns.o ./src/ge4a_load_n_store_cfns.su ./src/ge4a_load_n_store_sfns.d ./src/ge4a_load_n_store_sfns.o

.PHONY: clean-src

