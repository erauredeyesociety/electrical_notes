    .section .text
    .syntax unified

    .align

    .weak   mp_load_modify_store_s
    .type   mp_load_modify_store_s, %function

    .weak   mp_str_cpy_s
    .type   mp_str_cpy_s, %function
    .weak   mp_str_len_s
    .type   mp_str_len_s, %function

    .weak   mp_array_abs_sum_s
    .type   mp_array_abs_sum_s, %function
    .weak   mp_array_max_s
    .type   mp_array_max_s, %function


@ void mp_load_modify_store(int32_t *Ai32, int16_t *Bi16, int8_t *Ci8) {
@     Ai32 = 3 * Ai32 / 4;
@     Bi32 = 2 * Bi32 / 4;
@     Ci32 = 1 * Ci32 / 4;
@ }

@ void mp_load_modify_store_s(int32_t *Ai32, int16_t *Bi16, int8_t *Ci8);
@   Input:
@     * Ai32 -> r0
@     * Bi32 -> r1
@     * Ci32 -> r2
@   Output:
@     * None
@   Others:
@     * TBD

mp_load_modify_store_s:
    bx      lr


@ void mp_str_cpy_c2(uint8_t *src, uint8_t *dst) {
@     uint8_t ch;
@     while ((ch = *src++)) {
@         *dst++ = ch;
@     }
@     *dst = 0;
@ }

@ void mp_str_cpy_s(uint8_t *src, uint8_t *dst);
@   Input:
@     * src -> r0
@     * dst -> r1
@   Output:
@     * None
@   Others:
@     * TBD

mp_str_cpy_s:
    bx      lr


@ int mp_str_len_s(uint8_t *str);
@   Input:
@     * str -> r0
@   Output:
@     * int
@   Others:
@     * TBD

mp_str_len_s:
    bx      lr


@ int mp_array_abs_sum(int *pArr, int n) {
@     int sum = 0;
@     int i = 0;
@     while (i < n) {
@         int temp = *(pArr + i);
@         if (temp < 0) {
@             temp = -temp;
@         }
@         sum += temp;
@     }
@     return sum;
@ }

@ int mp_array_abs_sum_s(int *pArr, int n);
@   Input:
@     * pArr -> r0
@     * n -> r1
@   Output:
@     * int
@   Others:
@     * TBD

mp_array_abs_sum_s:
    bx      lr


@ int mp_array_max_s(int *pArr, int n);
@   Input:
@     * pArr -> r0
@     * n -> r1
@   Output:
@     * int
@   Others:
@     * TBD

mp_array_max_s:
    bx      lr


    .end                    @ end of the file
