################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/proj_mp/ge4a_load_n_store/test_ge4a_load_n_store/test_ge4a_load_n_store.c 

OBJS += \
./test/test_ge4a_load_n_store.o 

C_DEPS += \
./test/test_ge4a_load_n_store.d 


# Each subdirectory must supply rules for building sources it contributes
test/test_ge4a_load_n_store.o: C:/proj_mp/ge4a_load_n_store/test_ge4a_load_n_store/test_ge4a_load_n_store.c test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_ge4a_load_n_store -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-test

clean-test:
	-$(RM) ./test/test_ge4a_load_n_store.cyclo ./test/test_ge4a_load_n_store.d ./test/test_ge4a_load_n_store.o ./test/test_ge4a_load_n_store.su

.PHONY: clean-test

