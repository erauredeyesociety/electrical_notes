#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "unity.h"
#include "ge4a_load_n_store_fns.h"


void test_mp_load_modify_store(void) {
    int inp[] = {-16, -8, -4};
    int exp[] = {-12, -4, -1};

    mp_load_modify_store((int32_t *)&inp[0], (int16_t *)&inp[1],
            (int8_t *)&inp[2]);
    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, inp, 3);
}

void test_mp_str_cpy_c1(void) {
    char str1[] = "hello very long world";
    char str2[] = "hello short world";
    char act[50];

    mp_str_cpy_c1(str1, act);
    TEST_ASSERT_EQUAL_UINT8_ARRAY(str1, act, strlen(str1)+1);

    mp_str_cpy_c1(str2, act);
    TEST_ASSERT_EQUAL_UINT8_ARRAY(str2, act, strlen(str2)+1);
}

void test_mp_str_cpy_c2(void) {
    char str1[] = "hello very long world";
    char str2[] = "hello short world";
    char act[50];

    mp_str_cpy_c2(str1, act);
    TEST_ASSERT_EQUAL_UINT8_ARRAY(str1, act, strlen(str1)+1);

    mp_str_cpy_c2(str2, act);
    TEST_ASSERT_EQUAL_UINT8_ARRAY(str2, act, strlen(str2)+1);
}

void test_mp_array_abs_sum(void) {
    int arr[] = {-5, -3, -1,  0, 1, 3, 5};
    int n[] =   {3, 7};
    int exp[] = {9, 18};
    int act[2];

    act[0] = mp_array_abs_sum(arr, n[0]);
    act[1] = mp_array_abs_sum(arr, n[1]);

    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}

void test_mp_load_modify_store_s(void) {
    int inp[] = {-16, -8, -4};
    int exp[] = {-12, -4, -1};

    mp_load_modify_store_s((int32_t *)&inp[0], (int16_t *)&inp[1],
            (int8_t *)&inp[2]);
    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, inp, 3);
}

void test_mp_str_cpy_s(void) {
    char str1[] = "hello very long world";
    char str2[] = "hello short world";
    char act[50];

    mp_str_cpy_s(str1, act);
    TEST_ASSERT_EQUAL_UINT8_ARRAY(str1, act, strlen(str1)+1);

    mp_str_cpy_s(str2, act);
    TEST_ASSERT_EQUAL_UINT8_ARRAY(str2, act, strlen(str2)+1);
}

void test_mp_str_len_s(void) {
    char str1[] = "hi";
    char str2[] = "hello";
    int exp[] = {2, 5};
    int act[2];

    act[0] = mp_str_len_s(str1);
    act[1] = mp_str_len_s(str2);

    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}

void test_mp_array_abs_sum_s(void) {
    int arr[] = {-5, -3, -1,  0, 1, 3, 5};
    int n[] =   {3, 7};
    int exp[] = {9, 18};
    int act[2];

    act[0] = mp_array_abs_sum_s(arr, n[0]);
    act[1] = mp_array_abs_sum_s(arr, n[1]);

    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}

void test_mp_array_max_s(void) {
    int arr[] = {-3, -5, -1,  7};
    int n[] =   {3, 4};
    int exp[] = {-1, 7};
    int act[2];

    act[0] = mp_array_max_s(arr, n[0]);
    act[1] = mp_array_max_s(arr, n[1]);

    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}


void run_unity(void) {
    printf("\n\nRunning ge4a unit test-----------------\n");

    UNITY_BEGIN();

    RUN_TEST(test_mp_load_modify_store);
    RUN_TEST(test_mp_str_cpy_c1);
    RUN_TEST(test_mp_str_cpy_c2);
    RUN_TEST(test_mp_array_abs_sum);

    RUN_TEST(test_mp_load_modify_store_s);

    RUN_TEST(test_mp_str_cpy_s);
    RUN_TEST(test_mp_str_len_s);

    RUN_TEST(test_mp_array_abs_sum_s);
    RUN_TEST(test_mp_array_max_s);

    UNITY_END();

    while (1);
}
