#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>

void mp_load_modify_store(int32_t *Ai32, int16_t *Bi16, int8_t *Ci8);
void mp_str_cpy_c1(char *src, char *dst);
void mp_str_cpy_c2(char *src, char *dst);
int mp_array_abs_sum(int *pArr, int n);

void mp_load_modify_store_s(int32_t *Ai32, int16_t *Bi16, int8_t *Ci8);
void mp_str_cpy_s(char *src, char *dst);
int mp_str_len_s(char *str);
int mp_array_abs_sum_s(int *pArr, int n);
int mp_array_max_s(int *pArr, int n);

#ifdef __cplusplus
}
#endif /* __cplusplus */
