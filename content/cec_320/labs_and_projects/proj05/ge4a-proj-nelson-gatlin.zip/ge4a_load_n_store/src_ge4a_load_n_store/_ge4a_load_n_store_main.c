void run_usr_code(void) {

#if defined(UNIT_TEST)
    extern void run_unity(void);
    run_unity();
#else
    extern void run_app(void);
    run_app();
#endif

}
