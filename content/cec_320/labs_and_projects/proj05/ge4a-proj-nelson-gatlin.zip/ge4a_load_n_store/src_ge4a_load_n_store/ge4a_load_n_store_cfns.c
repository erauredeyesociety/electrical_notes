#include "mp_uart_redirect.h"
#include "ge4a_load_n_store_fns.h"
#include <stdint.h>

void mp_load_modify_store(int32_t *Ai32, int16_t *Bi16, int8_t *Ci8) {
    *Ai32 = 3 * *Ai32 / 4;
    *Bi16 = 2 * *Bi16 / 4;
    *Ci8 = 1 * *Ci8 / 4;
}

void mp_str_cpy_c1(char *src, char *dst) {
    while (*src) {
        *dst++ = *src++;
    }
    *dst = 0;
}

void mp_str_cpy_c2(char *src, char *dst) {
    uint8_t ch;
    while ((ch = *src++)) {
        *dst++ = ch;
    }
    *dst = 0;
}

int mp_array_abs_sum(int *pArr, int n) {
    int sum = 0;
    int i = 0;
    while (i < n) {
        int temp = *(pArr + i);
        if (temp < 0) {
            temp = -temp;
        }
        sum += temp;
        i++;
    }
    return sum;
}
