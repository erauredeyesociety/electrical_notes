#include <stdio.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "ge4a_load_n_store_fns.h"

void run_app(void) {
    printf("\n\nRunning ge5a main App-----------------\n");
    printf("This is now an empty app.\n");
    while (1);
}
