################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
C:/proj_mp/lg_lab_final_base_n_soln/soln/lg_lab_final_sfns.s 

C_SRCS += \
C:/proj_mp/lg_lab_final_base_n_soln/soln/lg_lab_final_cfns.c 

OBJS += \
./src_soln/lg_lab_final_cfns.o \
./src_soln/lg_lab_final_sfns.o 

S_DEPS += \
./src_soln/lg_lab_final_sfns.d 

C_DEPS += \
./src_soln/lg_lab_final_cfns.d 


# Each subdirectory must supply rules for building sources it contributes
src_soln/lg_lab_final_cfns.o: C:/proj_mp/lg_lab_final_base_n_soln/soln/lg_lab_final_cfns.c src_soln/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_lg_lab_final -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
src_soln/lg_lab_final_sfns.o: C:/proj_mp/lg_lab_final_base_n_soln/soln/lg_lab_final_sfns.s src_soln/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-src_soln

clean-src_soln:
	-$(RM) ./src_soln/lg_lab_final_cfns.cyclo ./src_soln/lg_lab_final_cfns.d ./src_soln/lg_lab_final_cfns.o ./src_soln/lg_lab_final_cfns.su ./src_soln/lg_lab_final_sfns.d ./src_soln/lg_lab_final_sfns.o

.PHONY: clean-src_soln

