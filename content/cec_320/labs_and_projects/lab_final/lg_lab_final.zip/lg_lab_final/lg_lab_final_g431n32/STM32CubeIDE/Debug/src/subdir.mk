################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
C:/proj_mp/lg_lab_final/src_lg_lab_final/lg_lab_final_sfns.s 

C_SRCS += \
C:/proj_mp/lg_lab_final/src_lg_lab_final/_lg_lab_final_main.c \
C:/proj_mp/lg_lab_final/src_lg_lab_final/lg_lab_final_app.c \
C:/proj_mp/lg_lab_final/src_lg_lab_final/lg_lab_final_cfns.c 

OBJS += \
./src/_lg_lab_final_main.o \
./src/lg_lab_final_app.o \
./src/lg_lab_final_cfns.o \
./src/lg_lab_final_sfns.o 

S_DEPS += \
./src/lg_lab_final_sfns.d 

C_DEPS += \
./src/_lg_lab_final_main.d \
./src/lg_lab_final_app.d \
./src/lg_lab_final_cfns.d 


# Each subdirectory must supply rules for building sources it contributes
src/_lg_lab_final_main.o: C:/proj_mp/lg_lab_final/src_lg_lab_final/_lg_lab_final_main.c src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_lg_lab_final -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
src/lg_lab_final_app.o: C:/proj_mp/lg_lab_final/src_lg_lab_final/lg_lab_final_app.c src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_lg_lab_final -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
src/lg_lab_final_cfns.o: C:/proj_mp/lg_lab_final/src_lg_lab_final/lg_lab_final_cfns.c src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_lg_lab_final -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
src/lg_lab_final_sfns.o: C:/proj_mp/lg_lab_final/src_lg_lab_final/lg_lab_final_sfns.s src/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-src

clean-src:
	-$(RM) ./src/_lg_lab_final_main.d ./src/_lg_lab_final_main.o ./src/_lg_lab_final_main.su ./src/lg_lab_final_app.d ./src/lg_lab_final_app.o ./src/lg_lab_final_app.su ./src/lg_lab_final_cfns.d ./src/lg_lab_final_cfns.o ./src/lg_lab_final_cfns.su ./src/lg_lab_final_sfns.d ./src/lg_lab_final_sfns.o

.PHONY: clean-src

