################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/proj_mp/lg_lab_final/test_lg_lab_final/test_lg_lab_final.c 

OBJS += \
./test/test_lg_lab_final.o 

C_DEPS += \
./test/test_lg_lab_final.d 


# Each subdirectory must supply rules for building sources it contributes
test/test_lg_lab_final.o: C:/proj_mp/lg_lab_final/test_lg_lab_final/test_lg_lab_final.c test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src_lg_lab_final -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-test

clean-test:
	-$(RM) ./test/test_lg_lab_final.d ./test/test_lg_lab_final.o ./test/test_lg_lab_final.su

.PHONY: clean-test

