#include <stdio.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "lg_lab_final_fns.h"

char Task1_str1[] = "Hello, this is Firstname Lastname.";
char Task1_str2[] = "I am working on the lab final."; 
char *pStr = NULL;

int run_app(void) {
    printf("\n\nLab final Main App-----------------\n");

    // Task 1:
    uint32_t A = 0x12345678;
    task1_func_s(&A);

    printf("First executable line of the user code.\n");
    pStr = Task1_str1;
    printf("String pointed by pStr: %s\n", pStr);
    pStr = Task1_str2;
    printf("String pointed by pStr: %s\n\n", pStr);    

    while (1);
}

/*

Subtasks for Task 1:
1. (4 pts) Set up a breakpoint in code "ldr r1, [r0]" in the assembly function
   task1_func_s. Build the App (Debug) and run the program. It should pause at
   this line. Obtain the value of r0 in the **Registers** view. Record the
   value in hexadecimal.
2. (4 pts) Step through the above assembly function and return to this program.
   Pause at Line 17. Obtain the value of local variable A in the **Variables**
   view. Record the value in hexadecimal.
3. (4 pts) Step through the C statement and stop at Line 19. Obtain the value
   of global variable pStr in the **Expression** view. Record the value in
   hexadecimal. Pause the program in Line 21 and record the value of pStr
   again.
4. (4 pts) Continue the pause at Line 21. Display the contents of the memory
   starting at 0x20000000. You should use the **Memory** view at the bottom
   of the debug perspective. Use *New Rendering* to display the contents in
   ASCII. You should be able to see the contents of string Task1_str1. Record
   it's starting address in hexadecimal.

Take screenshot for each of the above to include in the pdf solution sheet.
Also clearly list all the values of interests specified in the above text.

Note that you need to use your real name to replace the Firstname and Lastname
placeholders in Task1_str1.

*/
