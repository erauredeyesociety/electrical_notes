#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>

// Task 1 function
void task1_func_s(uint32_t *x); 

// Task 2 function
int32_t task2_func_c(int *arr, int n);

// Task 3 function
void task3_func_s(char *src, char *dst); 

#ifdef __cplusplus
}
#endif /* __cplusplus */
