#include <stdint.h>

// Write a C function to calculate the sum of the negative elements of an
// array. Do not use any existing functions.

int32_t task2_func_c(int *arr, int n) {

    return 0;
}
