#include <stdio.h>
#include <stdint.h>
#include "unity.h"
#include "lg_lab_final_fns.h"


void test_task2_func_c(void) {
    int arr[] = {1, -2, 3, -4};
    int n[]   = {2, 4};
    int exp[] = {-2, -6};
    int act[2];

    act[0] = task2_func_c(arr, n[0]);
    act[1] = task2_func_c(arr, n[1]);
    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);   
}


void test_task3_func_s(void) {
    char exp1[] = "Hello";
    char exp2[] = "Hi";
    char act[10];

    task3_func_s(exp1, act);;
    TEST_ASSERT_EQUAL_INT8_ARRAY(exp1, act, 6); 

    task3_func_s(exp2, act);;
    TEST_ASSERT_EQUAL_INT8_ARRAY(exp2, act, 3); 
}


void run_unity(void) {
    printf("\n\nLab final  Unit Test-----------------\n");

    UNITY_BEGIN();

    RUN_TEST(test_task2_func_c);
    RUN_TEST(test_task3_func_s);


    UNITY_END();
    
    while (1);
}
