#include <stdio.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "gc1s_ldr_n_str_n_macro_fns.h"
#include "ge1s_more_ldr_n_str_n_mov_fns.h"
#include "mp_print_m_word.h"

#define N 1024

uint8_t reservation[N] = { [0 ... N-1] = 0x11 };
R1toR6_t regs;

void mp_app(void) {
    printf("\n\nRunning ge1s main App-----------------\n");
    printf("\nMore load and store instructions and move instructions:\n");

    // Check if the Memory_block is in within the reservation.
    mp_print_reservation_addresses(reservation, N);

    printf("\nResults for Example 1: register-offset load operations:\n");
    mp_init_mem_block();
    mp_initialize_r1_to_r6_s(&regs);
    mp_reg_offset_load_s(&regs);
    mp_print_regs(&regs);

    printf("\nResults for Example 3: from C store statements:\n");
    mp_init_mem_block();
    uint32_t *p32 = (uint32_t *)0x20000200;
    uint32_t var32 = 0xDEADBEEF;
    int i = 2;
    mp_store_for_different_types_c(p32, i, var32);
    mp_print_memory_block((uint8_t *)p32, 16);

    printf("\nResults for Example 3: from ASM store instructions:\n");
    mp_init_mem_block();
    mp_store_for_different_types_s(p32, i, var32);
    mp_print_memory_block((uint8_t *)p32, 16);

    printf("\nResults for various pseudo load operations:\n");
    mp_various_pseudo_ldr_s(&regs);
    mp_print_regs(&regs);

    printf("\nMemory block initialization with different functions:\n");
    mp_init_mem_block_c1((uint8_t *)0x20000200, 16);
    mp_init_mem_block_c2((uint8_t *const)0x20000210, 16);
    mp_init_mem_block_s1((uint8_t *)0x20000220, 16);
    mp_init_mem_block_s2((uint8_t *const)0x20000230, 16);
    mp_print_memory_block((uint8_t *)0x20000200, 96);

    while (1);
}
