#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>

typedef struct {
    uint32_t R1b4, R2b4, R3b4, R4b4, R5b4, R6b4;
    uint32_t R1af, R2af, R3af, R4af, R5af, R6af;
} R1toR6_t;

void mp_print_reservation_addresses(uint8_t *ptr, int n);
void mp_init_mem_block(void);
void mp_print_regs(R1toR6_t *pReg);

int mp_initialize_r1_to_r6_s(R1toR6_t *pR1toR6);
void mp_32_bit_immediate_offset_load(R1toR6_t *pR1toR6);
void mp_8_n_16_bit_immediate_offset_load(R1toR6_t *pR1toR6);
void mp_init_mem_block_s(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */
