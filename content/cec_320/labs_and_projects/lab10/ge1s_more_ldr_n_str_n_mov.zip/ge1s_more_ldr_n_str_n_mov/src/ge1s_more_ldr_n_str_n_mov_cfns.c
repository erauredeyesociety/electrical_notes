#include "mp_uart_redirect.h"
#include "ge1s_more_ldr_n_str_n_mov_fns.h"
#include <stdint.h>

void mp_store_for_different_types_c(uint32_t *p32, int i, int var32) {
    *(p32 + i) = var32;             // Write 32 bits at address = (p32 + 4*i)
    *((uint16_t *)p32 + i) = var32; // Write 16 bits at address = (p32 + 2*i)
    *((uint8_t *)p32 + i) = var32;  // Write 8 bits at address = (p32 + i)
}

void mp_init_mem_block_c1(uint8_t *pArr, int n) {
    for (int i = 0; i < n; i++) {
        *pArr++ = 0x70 + (i << 1);  // We can change the pointer
    }
}

void mp_init_mem_block_c2(uint8_t *const pArr, int n) {
    for (int i = 0; i < n; i++) {
        // *pArr++ = 0x71 + (i << 1); error: increment of read-only parameter
        *(pArr + i) = 0x71 + (i << 1); // We can use an index variable
    }
}

void mp_print_memory_block(uint8_t *pArr, int n) {
    for (int i = 0; i < n; i += 8) {
        printf("0x%p: ", pArr);
        for (int j = 0; j <= ((n-1) % 8); j++) {
            printf(" 0x%02X", *pArr++);
        }
        printf("\n");
    }
}


int mp_array_abs_sum_var_ptr(int *pArr, int n) {
    int sum = 0;
    int i = 0;
    while (i < n) {
        int temp = *pArr++;
        if (temp < 0) {
            temp = -temp;
        }
        sum += temp;
        i++;
    }
    return sum;
}


int mp_array_abs_sum_cst_ptr(int *const pArr, int n) {
    int sum = 0;
    int i = 0;
    while (i < n) {
        int temp = *(pArr + i);
        if (temp < 0) {
            temp = -temp;
        }
        sum += temp;
        i++;
    }
    return sum;
}
