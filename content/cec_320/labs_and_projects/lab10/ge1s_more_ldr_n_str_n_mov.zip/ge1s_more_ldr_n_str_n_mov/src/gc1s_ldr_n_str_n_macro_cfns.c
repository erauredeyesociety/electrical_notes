#include "mp_uart_redirect.h"
#include "gc1s_ldr_n_str_n_macro_fns.h"
#include <stdint.h>

void mp_print_reservation_addresses(uint8_t *ptr, int n) {
    printf("\nStart address of mem: %p \n", ptr);
    printf("End address of mem: %p \n", ptr + n - 1);
}

void mp_init_mem_block(void) {
    uint8_t *p = (uint8_t *)0x20000200;
    for (int i = 0; i < 16; i++) {
        *p++ = 0x70 + (i << 1);
    }
}

void mp_print_regs(R1toR6_t *pReg) {
    printf("R1 b4 / af op: 0x%08lX, 0x%08lX \n", pReg->R1b4, pReg->R1af);
    printf("R2 b4 / af op: 0x%08lX, 0x%08lX \n", pReg->R2b4, pReg->R2af);
    printf("R3 b4 / af op: 0x%08lX, 0x%08lX \n", pReg->R3b4, pReg->R3af);
    printf("R4 b4 / af op: 0x%08lX, 0x%08lX \n", pReg->R4b4, pReg->R4af);
    printf("R5 b4 / af op: 0x%08lX, 0x%08lX \n", pReg->R5b4, pReg->R5af);
    printf("R6 b4 / af op: 0x%08lX, 0x%08lX \n", pReg->R6b4, pReg->R6af);
}
