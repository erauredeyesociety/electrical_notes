@ Define a micro to initialize special values for R1 to R6.
    .macro  initialize_r1_to_r6_local
        ldr     r1, =0x11111111
        ldr     r2, =0x22222222
        ldr     r3, =0x33333333
        ldr     r4, =0x44444444
        ldr     r5, =0x55555555
        ldr     r6, =0x66666666
    .endm

@ Store values of R1 to R6 to a data structure specified by R0 and offset.
    .macro  store_r1_to_r6_local, offset
        add     r0, r0, #\offset
        str     r1, [r0]
        str     r2, [r0, #4]
        str     r3, [r0, #8]
        str     r4, [r0, #12]
        str     r5, [r0, #16]
        str     r6, [r0, #20]
        sub     r0, r0, #\offset
    .endm
