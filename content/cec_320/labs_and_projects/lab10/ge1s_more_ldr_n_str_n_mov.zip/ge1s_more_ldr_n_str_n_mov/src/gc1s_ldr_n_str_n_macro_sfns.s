    .section .text
    .syntax unified
    
    .align

    .global mp_initialize_r1_to_r6_s
    .type   mp_initialize_r1_to_r6_s, %function
    .global mp_32_bit_immediate_offset_load
    .type   mp_32_bit_immediate_offset_load, %function
    .global mp_8_n_16_bit_immediate_offset_load
    .type   mp_8_n_16_bit_immediate_offset_load, %function
    .global mp_init_mem_block_s
    .type   mp_init_mem_block_s, %function


@ Define a micro to initialize special values for R1 to R6.
    .macro  initialize_r1_to_r6_local
        ldr     r1, =0x11111111
        ldr     r2, =0x22222222
        ldr     r3, =0x33333333
        ldr     r4, =0x44444444
        ldr     r5, =0x55555555
        ldr     r6, =0x66666666
    .endm

@ Store values of R1 to R6 to a data structure specified by R0 and offset.
    .macro  store_r1_to_r6_local, offset
        add     r0, r0, #\offset
        str     r1, [r0]
        str     r2, [r0, #4]
        str     r3, [r0, #8]
        str     r4, [r0, #12]
        str     r5, [r0, #16]
        str     r6, [r0, #20]
        sub     r0, r0, #\offset
    .endm

@ void mp_initialize_r1_to_r6_s(R1toR6_t *pR1toR6)
@   Input: 
@     * Ra -> r0 (Address)
@   Output:
@     * None 
mp_initialize_r1_to_r6_s:
    push    {r4-r6, lr}
    initialize_r1_to_r6_local 
    store_r1_to_r6_local 0   @ First half
    store_r1_to_r6_local 24  @ Second half
    pop     {r4-r6, pc}

@ void mp_32_bit_immediate_offset_load(R1toR6_t *pR1toR6)
@   Input: 
@     * Ra -> r0 (Address)
@   Output:
@     * None 
mp_32_bit_immediate_offset_load:
    push    {r4-r6, lr}         @ Push the related Regs in stack
    initialize_r1_to_r6_local   @ Initialization for stressing the changes

    @ Set values to the address registers 
    ldr     r1, =0x20000200
    ldr     r2, =0x20000204 
    ldr     r3, =0x2000020C

    store_r1_to_r6_local 0   @ Save the registers before operations

    @ Read via using LDR    @ Load instruction of the problem
    ldr     r4, [r1, #8]
    ldr     r5, [r2, #-4]!
    ldr     r6, [r3], #12

    store_r1_to_r6_local 24  @ Save the registers after operations
    pop     {r4-r6, pc}     @ Restore the values of Regs and return


@ void mp_8_n_16_bit_immediate_offset_load(R1toR6_t *pR1toR6)
@   Input: 
@     * Ra -> r0 (Address)
@   Output:
@     * None 
mp_8_n_16_bit_immediate_offset_load:
    push    {r4-r6, lr}         @ Push the related Regs in stack
    initialize_r1_to_r6_local   @ Initialization for stressing the changes

    @ Set values to the address registers 
    ldr     r1, =0x20000204
    ldr     r2, =0x20000206
    ldr     r3, =0x20000208

    store_r1_to_r6_local 0  @ Store the registers before operations

    @ Read via using LDR    @ Load instruction of the problem
    ldrsb     r4, [r1, #10]
    ldrsh     r5, [r2, #-2]!
    ldrsh     r6, [r3], #8

    store_r1_to_r6_local 24 @ Store the registers after operations
    pop     {r4-r6, pc}     @ Restore the values of Regs and return

@ void mp_init_mem_block_s(void) {
@     uint8_t *p = (uint8_t *)0x20000210;
@     for (int i = 0; i < 16; i++) {
@         *p++ = 0x70 + (i << 1);
@     }
@ }
mp_init_mem_block_s:
    ldr     r0, =0x20000210     @ *p = (uint8_t *)0x20000210
    ldr     r1, =0              @ int i = 0
    ldr     r2, =0x70           @ temp1 = 0x70
mp_init_mem_block_s_loop:
    cmp     r1, #16
    bge     mp_init_mem_block_s_end
    add     r3, r2, r1, lsl #1  @ temp2 = temp1 + (i << 1)
    strb    r3, [r0], #1        @ *p++ = temp2
    add     r1, #1              @ i++
    b       mp_init_mem_block_s_loop
mp_init_mem_block_s_end:
    bx      lr


    .end 
