#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include "gc1s_ldr_n_str_n_macro_fns.h"

void mp_store_for_different_types_c(uint32_t *p32, int i, int var32);
void mp_init_mem_block_c1(uint8_t *pArr, int n);
void mp_init_mem_block_c2(uint8_t *const pArr, int n);
void mp_print_memory_block(uint8_t *pArr, int n);

void mp_reg_offset_load_s(R1toR6_t *pR1toR6);
void mp_store_for_different_types_s(uint32_t *p32, int i, int var32);
void mp_various_pseudo_ldr_s(R1toR6_t *pR1toR6);
void mp_init_mem_block_s1(uint8_t *pArr, int n);
void mp_init_mem_block_s2(uint8_t *const pArr, int n);

int mp_array_abs_sum_var_ptr(int *pArr, int n);
int mp_array_abs_sum_var_ptr_s(int *pArr, int n);
int mp_array_abs_sum_cst_ptr(int *const pArr, int n);
int mp_array_abs_sum_cst_ptr_s(int *const pArr, int n);

int mp_array_pos_sum_cst_ptr_s(int *const pArr, int n);

#ifdef __cplusplus
}
#endif /* __cplusplus */
