#include <stdio.h>
#include <stdint.h>
#include "unity.h"
#include "ge1s_more_ldr_n_str_n_mov_fns.h"


void test_mp_array_abs_sum_var_ptr(void) {
    int arr[] = {-5, -3, -1,  0, 1, 3, 5};
    int n[] =   {3, 7};
    int exp[] = {9, 18};
    int act[2];

    act[0] = mp_array_abs_sum_var_ptr(arr, n[0]);
    act[1] = mp_array_abs_sum_var_ptr(arr, n[1]);

    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}

void test_mp_array_abs_sum_var_ptr_s(void) {
    int arr[] = {-5, -3, -1,  0, 1, 3, 5};
    int n[] =   {3, 7};
    int exp[] = {9, 18};
    int act[2];

    act[0] = mp_array_abs_sum_var_ptr_s(arr, n[0]);
    act[1] = mp_array_abs_sum_var_ptr_s(arr, n[1]);

    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}


void test_mp_array_abs_sum_cst_ptr(void) {
    int arr[] = {-5, -3, -1,  0, 1, 3, 5};
    int n[] =   {3, 7};
    int exp[] = {9, 18};
    int act[2];

    act[0] = mp_array_abs_sum_cst_ptr(arr, n[0]);
    act[1] = mp_array_abs_sum_cst_ptr(arr, n[1]);

    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}

void test_mp_array_abs_sum_cst_ptr_s(void) {
    int arr[] = {-5, -3, -1,  0, 1, 3, 5};
    int n[] =   {3, 7};
    int exp[] = {9, 18};
    int act[2];

    act[0] = mp_array_abs_sum_cst_ptr_s(arr, n[0]);
    act[1] = mp_array_abs_sum_cst_ptr_s(arr, n[1]);

    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}


void test_mp_array_pos_sum_cst_ptr_s(void) {
    int arr[] = {-5, -3, -1,  0, 1, 3, 5};
    int n[] =   {3, 7};
    int exp[] = {0, 9};   // first 3 are all negative → 0; full 7 → 0+1+3+5 = 9
    int act[2];

    act[0] = mp_array_pos_sum_cst_ptr_s(arr, n[0]);
    act[1] = mp_array_pos_sum_cst_ptr_s(arr, n[1]);

    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}


void mp_unity(void) {
    printf("\n\nRunning ge1s unit test-----------------\n");

    UNITY_BEGIN();

    RUN_TEST(test_mp_array_abs_sum_var_ptr);
    RUN_TEST(test_mp_array_abs_sum_var_ptr_s);
    RUN_TEST(test_mp_array_abs_sum_cst_ptr);
    RUN_TEST(test_mp_array_abs_sum_cst_ptr_s);
    RUN_TEST(test_mp_array_pos_sum_cst_ptr_s);

    UNITY_END();
    
    while (1);
}
