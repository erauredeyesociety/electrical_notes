################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
/opt/proj_mp/fo4b_ccs_n_cond_branch/src/fo4b_ccs_n_cond_branch_sfns.s 

C_SRCS += \
/opt/proj_mp/fo4b_ccs_n_cond_branch/src/_mp_main.c \
/opt/proj_mp/fo4b_ccs_n_cond_branch/src/fo4b_ccs_n_cond_branch_app.c \
/opt/proj_mp/fo4b_ccs_n_cond_branch/src/fo4b_ccs_n_cond_branch_cfns.c \
/opt/proj_mp/fo4b_ccs_n_cond_branch/lib/mp_uart_redirect.c \
/opt/proj_mp/fo4b_ccs_n_cond_branch/test/test_fo4b_ccs_n_cond_branch.c \
/opt/proj_mp/fo4b_ccs_n_cond_branch/lib/unity.c 

OBJS += \
./lib_src/_mp_main.o \
./lib_src/fo4b_ccs_n_cond_branch_app.o \
./lib_src/fo4b_ccs_n_cond_branch_cfns.o \
./lib_src/fo4b_ccs_n_cond_branch_sfns.o \
./lib_src/mp_uart_redirect.o \
./lib_src/test_fo4b_ccs_n_cond_branch.o \
./lib_src/unity.o 

S_DEPS += \
./lib_src/fo4b_ccs_n_cond_branch_sfns.d 

C_DEPS += \
./lib_src/_mp_main.d \
./lib_src/fo4b_ccs_n_cond_branch_app.d \
./lib_src/fo4b_ccs_n_cond_branch_cfns.d \
./lib_src/mp_uart_redirect.d \
./lib_src/test_fo4b_ccs_n_cond_branch.d \
./lib_src/unity.d 


# Each subdirectory must supply rules for building sources it contributes
lib_src/_mp_main.o: /opt/proj_mp/fo4b_ccs_n_cond_branch/src/_mp_main.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNITY_SUPPORT_64 -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/fo4b_ccs_n_cond_branch_app.o: /opt/proj_mp/fo4b_ccs_n_cond_branch/src/fo4b_ccs_n_cond_branch_app.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNITY_SUPPORT_64 -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/fo4b_ccs_n_cond_branch_cfns.o: /opt/proj_mp/fo4b_ccs_n_cond_branch/src/fo4b_ccs_n_cond_branch_cfns.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNITY_SUPPORT_64 -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/fo4b_ccs_n_cond_branch_sfns.o: /opt/proj_mp/fo4b_ccs_n_cond_branch/src/fo4b_ccs_n_cond_branch_sfns.s lib_src/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -c -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"
lib_src/mp_uart_redirect.o: /opt/proj_mp/fo4b_ccs_n_cond_branch/lib/mp_uart_redirect.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNITY_SUPPORT_64 -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/test_fo4b_ccs_n_cond_branch.o: /opt/proj_mp/fo4b_ccs_n_cond_branch/test/test_fo4b_ccs_n_cond_branch.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNITY_SUPPORT_64 -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/unity.o: /opt/proj_mp/fo4b_ccs_n_cond_branch/lib/unity.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNITY_SUPPORT_64 -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lib_src

clean-lib_src:
	-$(RM) ./lib_src/_mp_main.cyclo ./lib_src/_mp_main.d ./lib_src/_mp_main.o ./lib_src/_mp_main.su ./lib_src/fo4b_ccs_n_cond_branch_app.cyclo ./lib_src/fo4b_ccs_n_cond_branch_app.d ./lib_src/fo4b_ccs_n_cond_branch_app.o ./lib_src/fo4b_ccs_n_cond_branch_app.su ./lib_src/fo4b_ccs_n_cond_branch_cfns.cyclo ./lib_src/fo4b_ccs_n_cond_branch_cfns.d ./lib_src/fo4b_ccs_n_cond_branch_cfns.o ./lib_src/fo4b_ccs_n_cond_branch_cfns.su ./lib_src/fo4b_ccs_n_cond_branch_sfns.d ./lib_src/fo4b_ccs_n_cond_branch_sfns.o ./lib_src/mp_uart_redirect.cyclo ./lib_src/mp_uart_redirect.d ./lib_src/mp_uart_redirect.o ./lib_src/mp_uart_redirect.su ./lib_src/test_fo4b_ccs_n_cond_branch.cyclo ./lib_src/test_fo4b_ccs_n_cond_branch.d ./lib_src/test_fo4b_ccs_n_cond_branch.o ./lib_src/test_fo4b_ccs_n_cond_branch.su ./lib_src/unity.cyclo ./lib_src/unity.d ./lib_src/unity.o ./lib_src/unity.su

.PHONY: clean-lib_src

