#include <stdio.h>
#include <stdint.h>
#include "unity.h"
#include "fo4b_ccs_n_cond_branch_fns.h"


void test_mp_val_apsr_to_apsr(void) {
    uint64_t val_apsr0 = 0;
    uint64_t val_apsr1 = ((uint64_t)15) << (32+28);
    uint64_t val_apsr2 = ((uint64_t)10) << (32+28);
    APSR_t apsr0 = mp_val_apsr_to_apsr(val_apsr0);
    APSR_t apsr1 = mp_val_apsr_to_apsr(val_apsr1);
    APSR_t apsr2 = mp_val_apsr_to_apsr(val_apsr2);

    uint32_t exp[] = {0, 0xF0000000, 0xA0000000};
    uint32_t act[3];

    act[0] = *(uint32_t *)&apsr0;
    act[1] = *(uint32_t *)&apsr1;
    act[2] = *(uint32_t *)&apsr2;

    TEST_ASSERT_EQUAL_UINT32_ARRAY(exp, act, 3);
}

void test_mp_apsr_to_ccs_case1(void) {
    int N = 5;
    mp_initialize_n_bit_const(N);

    int x = -3;
    int y = 13;
    uint64_t val_apsr = mp_n_bit_x_minus_y_with_apsr(x, y, N);
    APSR_t apsr = mp_val_apsr_to_apsr(val_apsr);

    uint8_t exp[] = {0, 1,   1, 1, 0, 0,   0, 0, 1, 1}; // Example 1, Lctr 19
    CCS_t ccs;
    mp_apsr_to_ccs(apsr, &ccs);

    uint8_t *act = (uint8_t *)&ccs;

    TEST_ASSERT_EQUAL_UINT8_ARRAY(exp, act, 10);
}

void test_mp_apsr_to_ccs_case2(void) {
    int N = 5;
    mp_initialize_n_bit_const(N);

    int x = 17; // -15
    int y = 17; // -15
    uint64_t val_apsr = mp_n_bit_x_minus_y_with_apsr(x, y, N);
    APSR_t apsr = mp_val_apsr_to_apsr(val_apsr);

    uint8_t exp[] = {1, 0,   0, 1, 1, 0,   0, 1, 1, 0};
    CCS_t ccs;
    mp_apsr_to_ccs(apsr, &ccs);

    uint8_t *act = (uint8_t *)&ccs;

    TEST_ASSERT_EQUAL_UINT8_ARRAY(exp, act, 10);
}

void test_mp_max_ab_i_s(void) {
    int a[] = {0xFFFFFFFF, 0xFF, 0};
    int b[] = {0,             0, 0};
    int exp[] = {0,        0xFF, 0};
    int act[3];

    for (int i = 0; i < 3; i++) {
    	act[i] = mp_max_ab_i_s(a[i], b[i]);
    }
    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 3);
}

void test_mp_range_square_sum_standard_while_s(void) {
    int s[] =       {3, -3,  0, 0x100000};
    int e[] =       {0,  0,  3, 0x100000};
    int64_t exp[] = {0, 14, 14, 0x10000000000};
    int64_t act[4];

    for (int i = 0; i < 4; i++) {
    	act[i] = mp_range_square_sum_standard_while_s(s[i], e[i]);
    }
    TEST_ASSERT_EQUAL_INT64_ARRAY(exp, act, 4);
}


void mp_unity(void) {
    printf("\n\nRunning fo4b unit test-----------------\n");

    UNITY_BEGIN();

    RUN_TEST(test_mp_val_apsr_to_apsr);
    RUN_TEST(test_mp_apsr_to_ccs_case1);
    RUN_TEST(test_mp_apsr_to_ccs_case2);

    RUN_TEST(test_mp_max_ab_i_s);
    RUN_TEST(test_mp_range_square_sum_standard_while_s);

    UNITY_END();

    while (1);
}
