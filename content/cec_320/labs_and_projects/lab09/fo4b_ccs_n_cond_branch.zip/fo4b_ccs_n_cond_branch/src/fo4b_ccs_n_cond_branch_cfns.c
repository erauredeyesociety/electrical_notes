#include "mp_uart_redirect.h"
#include "fo4b_ccs_n_cond_branch_fns.h"
#include <stdint.h>

// Existing code from fm3d_status_flags_in_c

static NBit_Const_t NC;

void mp_initialize_n_bit_const(int N) {
    NC.C_N = (1 << N);        // Cardinality of N-bit number set
    NC.C_N1 = (1 << (N-1));   // C_{N-1}
    NC.N_MASK = NC.C_N - 1;   // MASK of N bits
    NC.U_MIN = 0;             // minimum value of unsigned number
    NC.U_MAX = NC.C_N - 1;    // max value of unsigned N-bit number
    NC.S_MIN = -NC.C_N1;      // min value of signed N-bit number
    NC.S_MAX = NC.C_N1 - 1;   // max value of signed N-bit number
}

uint32_t mp_n_bit_input_to_unsigned(int x, int N) {
	return x & NC.N_MASK;
}

int32_t mp_n_bit_input_to_signed(int x, int N) {
	x <<= 32 - N;
	x >>= 32 - N;
	return x;
}

int32_t mp_n_bit_unsigned_subtraction(int x, int y, int N) {
    uint32_t x_u = mp_n_bit_input_to_unsigned(x, N);
    uint32_t y_u = mp_n_bit_input_to_unsigned(y, N);
	return x_u - y_u;
}

int32_t mp_n_bit_signed_subtraction(int x, int y, int N) {
    int32_t x_s = mp_n_bit_input_to_signed(x, N);
    int32_t y_s = mp_n_bit_input_to_signed(y, N);
	return x_s - y_s;
}

uint64_t mp_n_bit_x_minus_y_with_apsr(int32_t x, int32_t y, int N) {
    uint32_t r_u;       // result in unsigned form
    int32_t r_s;        // result in signed form
    APSR_t apsr;        // apsr for status flags

    int32_t s_temp = mp_n_bit_unsigned_subtraction(x, y, N);
    if (s_temp < NC.U_MIN) {
        r_u = s_temp + NC.C_N;
        apsr.C = 0;     // there is a borrow
    } else {
        r_u = s_temp;
        apsr.C = 1;     // there is no borrow
    }

    s_temp = mp_n_bit_signed_subtraction(x, y, N);
    if (s_temp < NC.S_MIN) {
        r_s = s_temp + NC.C_N;
        apsr.V = 1;
    } else if (s_temp > NC.S_MAX) {
        r_s = s_temp - NC.C_N;
        apsr.V = 1;
    } else {
        r_s = s_temp;
        apsr.V = 0;
    }

    apsr.N = (r_s >> (N-1)) & 1;
    apsr.Z = (r_s == 0)? 1 : 0;

    // Assign the value of a bit-field var to a uint32_t var via pointer
    uint64_t result = *(uint32_t *)&apsr;
    return (result << 32) + r_u;
}


// New code for the current project

APSR_t mp_val_apsr_to_apsr(uint64_t val_apsr) {
    APSR_t apsr = *((APSR_t *)&val_apsr + 1);
    return apsr;
}

__attribute__((weak))
void mp_apsr_to_ccs(APSR_t apsr, CCS_t *pCcs) {

}
