#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include <math.h>

typedef struct { 
    int32_t C_N;   // (1 << N), cardinality of N-bit number set
    int32_t C_N1;  // (1 << (N-1)), C_{N-1}
    uint32_t N_MASK;    // (C_N - 1), MASK of N bits
    int32_t U_MIN; // 0, minimum value of unsigned number
    int32_t U_MAX; // (C_N - 1), max value of unsigned N-bit number
    int32_t S_MIN; // (-C_N1), min value of signed N-bit number
    int32_t S_MAX; // (C_N1 - 1), max value of signed N-bit number
} NBit_Const_t;    // struct for N-bit constants

typedef struct { 
    uint32_t _reserve   : 28;   // Reserve 28 bits
    uint32_t V          : 1;    // Bit 28, V flag
    uint32_t C          : 1;    // Bit 29, C flag
    uint32_t Z          : 1;    // Bit 30, Z flag
    uint32_t N          : 1;    // Bit 31, N flag
} APSR_t;           // Bit-field type for APSR flags

// N (< 32) is the number of bits of the system.
void mp_initialize_n_bit_const(int N);

uint32_t mp_n_bit_input_to_unsigned(int x, int N);
int32_t mp_n_bit_input_to_signed(int x, int N);
int32_t mp_n_bit_unsigned_subtraction(int x, int y, int N);
int32_t mp_n_bit_signed_subtraction(int x, int y, int N);

uint64_t mp_n_bit_x_minus_y_with_apsr(int32_t x, int32_t y, int N);


// New code for the project

typedef struct { 
    uint8_t EQ; 
    uint8_t NE; 

    uint8_t LT; 
    uint8_t LE; 
    uint8_t GE; 
    uint8_t GT; 

    uint8_t LO; 
    uint8_t LS; 
    uint8_t HS; 
    uint8_t HI;  
} CCS_t;   

APSR_t mp_val_apsr_to_apsr(uint64_t val_apsr);
void mp_apsr_to_ccs(APSR_t apsr, CCS_t *pCcs);

int32_t mp_max_ab_i_s(int a, int b);
int64_t mp_range_square_sum_standard_while_s(int s, int e);

#ifdef __cplusplus
}
#endif /* __cplusplus */
