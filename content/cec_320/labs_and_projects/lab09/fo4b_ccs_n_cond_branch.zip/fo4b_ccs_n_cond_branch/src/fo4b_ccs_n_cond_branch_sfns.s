    .section .text
    .syntax unified

    .align

    .weak   mp_max_ab_i_s
    .type   mp_max_ab_i_s, %function
    .weak   mp_range_square_sum_standard_while_s
    .type   mp_range_square_sum_standard_while_s, %function


@ int mp_max_ab_i_c(int a, int b) {
@     if (a >= b) {
@         return a;
@     } else {
@         return b;
@     }
@ }
@ int mp_max_ab_i_s(int a, int b)
@   Input:
@     * a -> r0
@     * b -> r1
@   Output:
@     * r0
mp_max_ab_i_s:

mp_max_ab_i_s_end_if:
    bx      lr


@ int64_t mp_range_square_sum_standard_while_c(int s, int e) {
@     int64_t sum = 0;
@     int64_t i = s;
@     while (i <= e) {
@         sum += i*i;
@         i++;
@     }
@     return sum;
@ }
@ int64_t mp_range_square_sum_standard_while_s(int s, int e)
@   Input:
@     * s -> r0 (will be used as i)
@     * e -> r1
@   Output:
@     * r1:r0
@   Others:
@     * sum_low_word -> r2, sum_high_word -> r3
mp_range_square_sum_standard_while_s:

    bx      lr                      @ return sum

    .end                    @ end of the file
