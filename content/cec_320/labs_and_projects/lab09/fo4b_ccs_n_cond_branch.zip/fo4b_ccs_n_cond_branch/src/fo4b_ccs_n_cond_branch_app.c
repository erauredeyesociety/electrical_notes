#include <stdio.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "fo4b_ccs_n_cond_branch_fns.h"

void mp_app(void) {
    printf("\n\nRunning fo4b main App-----------------\n");
    printf("\nAPSR -> CCS; Conditional Branch:\n");

    int N = 5;      // number of bits
    mp_initialize_n_bit_const(N);

    uint64_t val_apsr;

    // Binary unsigned addition and subtraction:
    int x=11, y=28;

    printf("%d-bit binary addition %d - %d results: \n", N, y, x);
    val_apsr = mp_n_bit_x_minus_y_with_apsr(y, x, N);

    (void)val_apsr; // remove the "not used" warning

    while (1);
}
