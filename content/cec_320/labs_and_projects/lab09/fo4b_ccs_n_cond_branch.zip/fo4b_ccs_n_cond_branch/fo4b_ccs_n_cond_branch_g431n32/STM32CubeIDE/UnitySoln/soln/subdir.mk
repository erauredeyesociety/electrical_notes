################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
C:/proj_mp/fo4b_ccs_n_cond_branch_soln/src_soln/fo4b_ccs_n_cond_branch_sfns_soln.s 

C_SRCS += \
C:/proj_mp/fo4b_ccs_n_cond_branch_soln/src_soln/fo4b_ccs_n_cond_branch_cfns_soln.c 

OBJS += \
./soln/fo4b_ccs_n_cond_branch_cfns_soln.o \
./soln/fo4b_ccs_n_cond_branch_sfns_soln.o 

S_DEPS += \
./soln/fo4b_ccs_n_cond_branch_sfns_soln.d 

C_DEPS += \
./soln/fo4b_ccs_n_cond_branch_cfns_soln.d 


# Each subdirectory must supply rules for building sources it contributes
soln/fo4b_ccs_n_cond_branch_cfns_soln.o: C:/proj_mp/fo4b_ccs_n_cond_branch_soln/src_soln/fo4b_ccs_n_cond_branch_cfns_soln.c soln/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -DUNITY_SUPPORT_64 -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
soln/fo4b_ccs_n_cond_branch_sfns_soln.o: C:/proj_mp/fo4b_ccs_n_cond_branch_soln/src_soln/fo4b_ccs_n_cond_branch_sfns_soln.s soln/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-soln

clean-soln:
	-$(RM) ./soln/fo4b_ccs_n_cond_branch_cfns_soln.cyclo ./soln/fo4b_ccs_n_cond_branch_cfns_soln.d ./soln/fo4b_ccs_n_cond_branch_cfns_soln.o ./soln/fo4b_ccs_n_cond_branch_cfns_soln.su ./soln/fo4b_ccs_n_cond_branch_sfns_soln.d ./soln/fo4b_ccs_n_cond_branch_sfns_soln.o

.PHONY: clean-soln

