#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>


__attribute__((weak))
void mp_app(void) {
    printf("\n\nRunning ee4u main App-----------------\n");

    while (1);
}
