#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include <math.h>

float mp_uq_and_q_mn_decoding(uint32_t D, int s, int m, int n);
uint32_t mp_uq_and_q_mn_encoding(float f, int s, int m, int n);
float mp_q_mn_multiplication(float f1, float f2, int m, int n);

#ifdef __cplusplus
}
#endif /* __cplusplus */
