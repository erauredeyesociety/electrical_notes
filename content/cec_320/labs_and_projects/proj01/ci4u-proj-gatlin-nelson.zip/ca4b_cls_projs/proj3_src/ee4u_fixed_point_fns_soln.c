#include "ee4u_fixed_point_fns.h"

/*
Function for UQm.n and Qm.n decoding. Given the coded data D and the number
    of bits for each field, determine the real number f.

Input:
-   D: the encoded data.
-   s: the sign of the expression. 1 for Qm.n and 0 for UQm.n.
-   m: the number of bits in the whole number section.
-   n: the number of bits in the fraction section.

Return:
-   f: the real number.
*/

float mp_uq_and_q_mn_decoding(uint32_t D, int s, int m, int n) {
    int32_t intD = (int32_t)D;
    if (s) {
        int N = m + n + 1;
        int cardinality = 1 << N;
        int max_positive = (cardinality >> 1) - 1;
        if (intD > max_positive) {
            intD -= cardinality;
        }
    }
    float f = (float)intD;
    f /= (1 << n);
    return f;
}

/*
Function for UQm.n and Qm.n encoding. Given the real number f and the number
    of bits for each field, determine the real number f.

Input:
-   f: the real number to be encoded.
-   s: the sign of the expression. 1 for Qm.n and 0 for UQm.n.
-   m: the number of bits in the whole number section.
-   n: the number of bits in the fraction section.

Return:
-   D: the encoded data.
*/

uint32_t mp_uq_and_q_mn_encoding(float f, int s, int m, int n) {
    float fn = f * (1 << n);
    int32_t intD = lrint(fn);
    uint32_t D = (uint32_t)intD;
    if (intD < 0) {
        D = intD + (1 << 31) + (1 << 31);
    }
    return D;
}

/*
Function for Qm.n multiplication. Given real numbers f1 and f1 and
    the number of bits for each field, determine the product of f1 and f2.
    Note that we only handle Qm.n, not UQm.n

Input:
-   f1: the real number for operand 1.
-   f2: the real number for operand 2.
-   m: the number of bits in the whole number section.
-   n: the number of bits in the fraction section.

Return:
-   p: the product of f1 * f2 using Qm.n multiplication.
*/

float mp_q_mn_multiplication(float f1, float f2, int m, int n) {
    int I1 = (int) mp_uq_and_q_mn_encoding(f1, 1, m, n);
    int I2 = (int) mp_uq_and_q_mn_encoding(f2, 1, m, n);
    int I3 = I1 * I2;
    I3 >>= n;
    float prod = mp_uq_and_q_mn_decoding(I3, 1, m, n);
    return prod;
}
