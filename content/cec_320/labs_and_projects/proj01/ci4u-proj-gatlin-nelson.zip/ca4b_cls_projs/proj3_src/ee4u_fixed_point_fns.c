#include "ee4u_fixed_point_fns.h"

/*
Function for UQm.n and Qm.n decoding. Given the coded data D and the number
    of bits for each field, determine the real number f.

Input:
-   D: encoded data.
-   s: type of representation: 1 for Qm.n (signed); 0 for UQm.n.
-   m: number of bits in the whole number field.
-   n: number of bits in the fraction field.

Return:
-   f: the real number.
*/

__attribute__((weak))
float mp_uq_and_q_mn_decoding(uint32_t D, int s, int m, int n) {
    float f = 0.0;
    return f;
}

/*
Function for UQm.n and Qm.n encoding. Given the real number f and the number
    of bits for each field, determine the real number f.

Input:
-   f: real number to be encoded.
-   s: type of representation: 1 for Qm.n (signed); 0 for UQm.n.
-   m: number of bits in the whole number field.
-   n: number of bits in the fraction field.

Return:
-   D: the encoded data.
*/

__attribute__((weak))
uint32_t mp_uq_and_q_mn_encoding(float f, int s, int m, int n) {
    uint32_t D = 0;
    return D;
}

/*
Function for Qm.n multiplication. Given real numbers f1 and f1 and
    the number of bits for each field, determine the product of f1 and f2.
    Note that we only handle Qm.n, not UQm.n

Input:
-   f1: real number used as operand 1.
-   f2: real number used as operand 2.
-   m: number of bits in the whole number section.
-   n: number of bits in the fraction section.

Return:
-   p: the product of f1 * f2 using Qm.n multiplication.
*/

__attribute__((weak))
float mp_q_mn_multiplication(float f1, float f2, int m, int n) {
    float prod = 0.0;
    return prod;
}
