#include <stdio.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "proj1_fns.h"

void mp_app(void) {
    printf("\nRunning Proj1 main App:\n");

    while (1);
}
