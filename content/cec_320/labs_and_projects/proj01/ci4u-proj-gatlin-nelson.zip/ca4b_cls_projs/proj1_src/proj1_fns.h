#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void mp_swap(int *a, int *b);
void mp_partial_sum(int *arr, int arr_size, int *result);
int mp_reverse_str(char *src, char *dst);

#ifdef __cplusplus
}
#endif /* __cplusplus */
