void mp_swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void mp_partial_sum(int *arr, int arr_size, int *result) {
    result[0] = 0;
    result[1] = 0;

    for (int i = 0; i < arr_size; i++) {
        if (i % 2 == 0) {
            result[0] += *(arr + i);
        } else {
            result[1] += arr[i];
        }
    }
}

int mp_reverse_str(char *src, char *dst) {
    int len = 0;
    char *p = src;

    while (*p != '\0') {
        len++;
        p++;
    }

    for (int i = 0; i < len; i++) {
        dst[i] = src[len - 1 - i];
    }
    dst[len] = '\0';

    return len;
}
