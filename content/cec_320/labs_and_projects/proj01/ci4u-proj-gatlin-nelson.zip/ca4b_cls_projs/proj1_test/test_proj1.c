#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "unity.h"
#include "proj1_fns.h"


void test_mp_swap(void) {
    int exp[] = {2, 1};
    int act[] = {1, 2};
    mp_swap(&act[0], &act[1]);
    TEST_ASSERT_EQUAL_INT_ARRAY(exp, act, 2);
}

void test_mp_partial_sum(void) {
    int arr[] = {1, 2, 3, 4, 5, 6};
    int exp1[] = {1, 2};   // arr_size = 2
    int exp2[] = {9, 12};  // arr_size = 6
    int act1[2];
    int act2[2];

    mp_partial_sum(arr, 2, act1);
    mp_partial_sum(arr, 6, act2);

    TEST_ASSERT_EQUAL_INT_ARRAY(exp1, act1, 2);
    TEST_ASSERT_EQUAL_INT_ARRAY(exp2, act2, 2);
}

void test_mp_reverse_str(void) {
    char src[] = "Hello.";
    char dst[7];
    char exp[] = ".olleH";

    int result = mp_reverse_str(src, dst);

    TEST_ASSERT_EQUAL_INT(6, result);
    TEST_ASSERT_EQUAL_UINT8_ARRAY(exp, dst, 7);
}


void mp_unity(void) {
    printf("\nRunning Proj1 unit test:\n");

    UNITY_BEGIN();

    RUN_TEST(test_mp_swap);
    RUN_TEST(test_mp_partial_sum);
    RUN_TEST(test_mp_reverse_str);

    UNITY_END();

    while (1);
}
