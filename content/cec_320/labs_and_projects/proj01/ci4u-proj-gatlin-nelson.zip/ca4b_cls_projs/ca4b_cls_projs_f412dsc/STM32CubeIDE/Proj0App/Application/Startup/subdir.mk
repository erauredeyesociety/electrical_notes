################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
../Application/Startup/startup_stm32f412zgtx.s 

OBJS += \
./Application/Startup/startup_stm32f412zgtx.o 

S_DEPS += \
./Application/Startup/startup_stm32f412zgtx.d 


# Each subdirectory must supply rules for building sources it contributes
Application/Startup/%.o: ../Application/Startup/%.s Application/Startup/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-Application-2f-Startup

clean-Application-2f-Startup:
	-$(RM) ./Application/Startup/startup_stm32f412zgtx.d ./Application/Startup/startup_stm32f412zgtx.o

.PHONY: clean-Application-2f-Startup

