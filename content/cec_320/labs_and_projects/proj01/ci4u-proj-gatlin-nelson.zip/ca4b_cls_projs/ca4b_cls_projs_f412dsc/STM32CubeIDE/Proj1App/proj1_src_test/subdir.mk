################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/proj_mp/ca4b_cls_projs/proj1_src/_mp_main.c \
C:/proj_mp/ca4b_cls_projs/proj1_src/proj1_app.c \
C:/proj_mp/ca4b_cls_projs/proj1_src/proj1_cfns.c \
C:/proj_mp/ca4b_cls_projs/proj1_test/test_proj1.c 

OBJS += \
./proj1_src_test/_mp_main.o \
./proj1_src_test/proj1_app.o \
./proj1_src_test/proj1_cfns.o \
./proj1_src_test/test_proj1.o 

C_DEPS += \
./proj1_src_test/_mp_main.d \
./proj1_src_test/proj1_app.d \
./proj1_src_test/proj1_cfns.d \
./proj1_src_test/test_proj1.d 


# Each subdirectory must supply rules for building sources it contributes
proj1_src_test/_mp_main.o: C:/proj_mp/ca4b_cls_projs/proj1_src/_mp_main.c proj1_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj1_src_test/proj1_app.o: C:/proj_mp/ca4b_cls_projs/proj1_src/proj1_app.c proj1_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj1_src_test/proj1_cfns.o: C:/proj_mp/ca4b_cls_projs/proj1_src/proj1_cfns.c proj1_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj1_src_test/test_proj1.o: C:/proj_mp/ca4b_cls_projs/proj1_test/test_proj1.c proj1_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-proj1_src_test

clean-proj1_src_test:
	-$(RM) ./proj1_src_test/_mp_main.cyclo ./proj1_src_test/_mp_main.d ./proj1_src_test/_mp_main.o ./proj1_src_test/_mp_main.su ./proj1_src_test/proj1_app.cyclo ./proj1_src_test/proj1_app.d ./proj1_src_test/proj1_app.o ./proj1_src_test/proj1_app.su ./proj1_src_test/proj1_cfns.cyclo ./proj1_src_test/proj1_cfns.d ./proj1_src_test/proj1_cfns.o ./proj1_src_test/proj1_cfns.su ./proj1_src_test/test_proj1.cyclo ./proj1_src_test/test_proj1.d ./proj1_src_test/test_proj1.o ./proj1_src_test/test_proj1.su

.PHONY: clean-proj1_src_test

