################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/proj_mp/ca4b_cls_projs/proj3_src/_mp_main.c \
C:/proj_mp/ca4b_cls_projs/proj3_src/ee4u_fixed_point_fns.c \
C:/proj_mp/ca4b_cls_projs/proj3_src/ee4u_fixed_point_fns_soln.c \
C:/proj_mp/ca4b_cls_projs/proj3_src/ee4u_fixed_point_operations_app.c \
C:/proj_mp/ca4b_cls_projs/proj3_src/ee4u_fixed_point_operations_app_soln.c \
C:/proj_mp/ca4b_cls_projs/proj3_test/test_ee4u_fixed_point_fns.c 

OBJS += \
./proj3_src_test/_mp_main.o \
./proj3_src_test/ee4u_fixed_point_fns.o \
./proj3_src_test/ee4u_fixed_point_fns_soln.o \
./proj3_src_test/ee4u_fixed_point_operations_app.o \
./proj3_src_test/ee4u_fixed_point_operations_app_soln.o \
./proj3_src_test/test_ee4u_fixed_point_fns.o 

C_DEPS += \
./proj3_src_test/_mp_main.d \
./proj3_src_test/ee4u_fixed_point_fns.d \
./proj3_src_test/ee4u_fixed_point_fns_soln.d \
./proj3_src_test/ee4u_fixed_point_operations_app.d \
./proj3_src_test/ee4u_fixed_point_operations_app_soln.d \
./proj3_src_test/test_ee4u_fixed_point_fns.d 


# Each subdirectory must supply rules for building sources it contributes
proj3_src_test/_mp_main.o: C:/proj_mp/ca4b_cls_projs/proj3_src/_mp_main.c proj3_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj3_src_test/ee4u_fixed_point_fns.o: C:/proj_mp/ca4b_cls_projs/proj3_src/ee4u_fixed_point_fns.c proj3_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj3_src_test/ee4u_fixed_point_fns_soln.o: C:/proj_mp/ca4b_cls_projs/proj3_src/ee4u_fixed_point_fns_soln.c proj3_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj3_src_test/ee4u_fixed_point_operations_app.o: C:/proj_mp/ca4b_cls_projs/proj3_src/ee4u_fixed_point_operations_app.c proj3_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj3_src_test/ee4u_fixed_point_operations_app_soln.o: C:/proj_mp/ca4b_cls_projs/proj3_src/ee4u_fixed_point_operations_app_soln.c proj3_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj3_src_test/test_ee4u_fixed_point_fns.o: C:/proj_mp/ca4b_cls_projs/proj3_test/test_ee4u_fixed_point_fns.c proj3_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-proj3_src_test

clean-proj3_src_test:
	-$(RM) ./proj3_src_test/_mp_main.cyclo ./proj3_src_test/_mp_main.d ./proj3_src_test/_mp_main.o ./proj3_src_test/_mp_main.su ./proj3_src_test/ee4u_fixed_point_fns.cyclo ./proj3_src_test/ee4u_fixed_point_fns.d ./proj3_src_test/ee4u_fixed_point_fns.o ./proj3_src_test/ee4u_fixed_point_fns.su ./proj3_src_test/ee4u_fixed_point_fns_soln.cyclo ./proj3_src_test/ee4u_fixed_point_fns_soln.d ./proj3_src_test/ee4u_fixed_point_fns_soln.o ./proj3_src_test/ee4u_fixed_point_fns_soln.su ./proj3_src_test/ee4u_fixed_point_operations_app.cyclo ./proj3_src_test/ee4u_fixed_point_operations_app.d ./proj3_src_test/ee4u_fixed_point_operations_app.o ./proj3_src_test/ee4u_fixed_point_operations_app.su ./proj3_src_test/ee4u_fixed_point_operations_app_soln.cyclo ./proj3_src_test/ee4u_fixed_point_operations_app_soln.d ./proj3_src_test/ee4u_fixed_point_operations_app_soln.o ./proj3_src_test/ee4u_fixed_point_operations_app_soln.su ./proj3_src_test/test_ee4u_fixed_point_fns.cyclo ./proj3_src_test/test_ee4u_fixed_point_fns.d ./proj3_src_test/test_ee4u_fixed_point_fns.o ./proj3_src_test/test_ee4u_fixed_point_fns.su

.PHONY: clean-proj3_src_test

