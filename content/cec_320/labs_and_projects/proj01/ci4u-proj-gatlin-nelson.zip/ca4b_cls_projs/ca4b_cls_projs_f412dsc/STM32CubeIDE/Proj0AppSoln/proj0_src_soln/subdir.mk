################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
C:/proj_mp/ca4b_cls_projs_soln/proj0_src_soln/cb4a_str_case_cvt_sfns_soln.s 

C_SRCS += \
C:/proj_mp/ca4b_cls_projs_soln/proj0_src_soln/cb4a_str_case_cvt_app_soln.c \
C:/proj_mp/ca4b_cls_projs_soln/proj0_src_soln/cb4a_str_case_cvt_cfns_soln.c 

OBJS += \
./proj0_src_soln/cb4a_str_case_cvt_app_soln.o \
./proj0_src_soln/cb4a_str_case_cvt_cfns_soln.o \
./proj0_src_soln/cb4a_str_case_cvt_sfns_soln.o 

S_DEPS += \
./proj0_src_soln/cb4a_str_case_cvt_sfns_soln.d 

C_DEPS += \
./proj0_src_soln/cb4a_str_case_cvt_app_soln.d \
./proj0_src_soln/cb4a_str_case_cvt_cfns_soln.d 


# Each subdirectory must supply rules for building sources it contributes
proj0_src_soln/cb4a_str_case_cvt_app_soln.o: C:/proj_mp/ca4b_cls_projs_soln/proj0_src_soln/cb4a_str_case_cvt_app_soln.c proj0_src_soln/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj0_src_soln/cb4a_str_case_cvt_cfns_soln.o: C:/proj_mp/ca4b_cls_projs_soln/proj0_src_soln/cb4a_str_case_cvt_cfns_soln.c proj0_src_soln/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj0_src_soln/cb4a_str_case_cvt_sfns_soln.o: C:/proj_mp/ca4b_cls_projs_soln/proj0_src_soln/cb4a_str_case_cvt_sfns_soln.s proj0_src_soln/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-proj0_src_soln

clean-proj0_src_soln:
	-$(RM) ./proj0_src_soln/cb4a_str_case_cvt_app_soln.cyclo ./proj0_src_soln/cb4a_str_case_cvt_app_soln.d ./proj0_src_soln/cb4a_str_case_cvt_app_soln.o ./proj0_src_soln/cb4a_str_case_cvt_app_soln.su ./proj0_src_soln/cb4a_str_case_cvt_cfns_soln.cyclo ./proj0_src_soln/cb4a_str_case_cvt_cfns_soln.d ./proj0_src_soln/cb4a_str_case_cvt_cfns_soln.o ./proj0_src_soln/cb4a_str_case_cvt_cfns_soln.su ./proj0_src_soln/cb4a_str_case_cvt_sfns_soln.d ./proj0_src_soln/cb4a_str_case_cvt_sfns_soln.o

.PHONY: clean-proj0_src_soln

