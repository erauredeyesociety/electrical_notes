################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
/opt/proj_mp/ca4b_cls_projs/proj0_src/cb4a_str_case_cvt_sfns.s 

C_SRCS += \
/opt/proj_mp/ca4b_cls_projs/proj0_src/_mp_main.c \
/opt/proj_mp/ca4b_cls_projs/proj0_src/cb4a_str_case_cvt_app.c \
/opt/proj_mp/ca4b_cls_projs/proj0_src/cb4a_str_case_cvt_cfns.c \
/opt/proj_mp/ca4b_cls_projs/proj0_test/test_cb4a_str_case_cvt.c 

OBJS += \
./proj0_src_test/_mp_main.o \
./proj0_src_test/cb4a_str_case_cvt_app.o \
./proj0_src_test/cb4a_str_case_cvt_cfns.o \
./proj0_src_test/cb4a_str_case_cvt_sfns.o \
./proj0_src_test/test_cb4a_str_case_cvt.o 

S_DEPS += \
./proj0_src_test/cb4a_str_case_cvt_sfns.d 

C_DEPS += \
./proj0_src_test/_mp_main.d \
./proj0_src_test/cb4a_str_case_cvt_app.d \
./proj0_src_test/cb4a_str_case_cvt_cfns.d \
./proj0_src_test/test_cb4a_str_case_cvt.d 


# Each subdirectory must supply rules for building sources it contributes
proj0_src_test/_mp_main.o: /opt/proj_mp/ca4b_cls_projs/proj0_src/_mp_main.c proj0_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj0_src_test/cb4a_str_case_cvt_app.o: /opt/proj_mp/ca4b_cls_projs/proj0_src/cb4a_str_case_cvt_app.c proj0_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj0_src_test/cb4a_str_case_cvt_cfns.o: /opt/proj_mp/ca4b_cls_projs/proj0_src/cb4a_str_case_cvt_cfns.c proj0_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
proj0_src_test/cb4a_str_case_cvt_sfns.o: /opt/proj_mp/ca4b_cls_projs/proj0_src/cb4a_str_case_cvt_sfns.s proj0_src_test/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"
proj0_src_test/test_cb4a_str_case_cvt.o: /opt/proj_mp/ca4b_cls_projs/proj0_test/test_cb4a_str_case_cvt.c proj0_src_test/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -DUNIT_TEST -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../proj0_src -I../../../proj1_src -I../../../proj2_src -I../../../proj3_src -I../../../proj4_src -I../../../proj5_src -I../../../proj6_src -I../../../projx_src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-proj0_src_test

clean-proj0_src_test:
	-$(RM) ./proj0_src_test/_mp_main.cyclo ./proj0_src_test/_mp_main.d ./proj0_src_test/_mp_main.o ./proj0_src_test/_mp_main.su ./proj0_src_test/cb4a_str_case_cvt_app.cyclo ./proj0_src_test/cb4a_str_case_cvt_app.d ./proj0_src_test/cb4a_str_case_cvt_app.o ./proj0_src_test/cb4a_str_case_cvt_app.su ./proj0_src_test/cb4a_str_case_cvt_cfns.cyclo ./proj0_src_test/cb4a_str_case_cvt_cfns.d ./proj0_src_test/cb4a_str_case_cvt_cfns.o ./proj0_src_test/cb4a_str_case_cvt_cfns.su ./proj0_src_test/cb4a_str_case_cvt_sfns.d ./proj0_src_test/cb4a_str_case_cvt_sfns.o ./proj0_src_test/test_cb4a_str_case_cvt.cyclo ./proj0_src_test/test_cb4a_str_case_cvt.d ./proj0_src_test/test_cb4a_str_case_cvt.o ./proj0_src_test/test_cb4a_str_case_cvt.su

.PHONY: clean-proj0_src_test

