    .section .text
    .syntax unified

    .align

    .global mp_str2lower_s
    .type   mp_str2lower_s, %function


mp_str2lower_s:
@ str -> r0, num_cvted -> r1, ch -> r2

    ldr     r1, =0

mp_str2lower_s_lp:
    ldrb    r2, [r0], #1

    cbz     r2, mp_str2lower_s_end

    cmp     r2, #65   @ 'A'
    blo     mp_str2lower_s_lp

    cmp     r2, #90   @ 'Z'
    bhi     mp_str2lower_s_lp

    add     r2, #32
    strb    r2, [r0, #-1]
    add     r1, #1
    b       mp_str2lower_s_lp

mp_str2lower_s_end:
    mov     r0, r1
    bx      lr


    .end                    @ end of the file
