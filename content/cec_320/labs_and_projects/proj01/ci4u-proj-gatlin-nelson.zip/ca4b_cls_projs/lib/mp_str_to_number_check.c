#include <stdbool.h>
#include <string.h>
#include "mp_str_to_number_check.h"

// Check if this is an integer in decimal
bool is_dec_int_num(char *str) {
    bool dec_int = true;

    // Remove leading spaces
    if (*str == ' ') {
        str++;
    }

    // Check negative sign
    if (*str == '-') {
        str++;
    }

    // Check if 0 is the leading 0 for oct
    int len = strlen(str);
    if (*str == '0' && len > 1) {
        dec_int = false;
        return dec_int;
    }

    // Check other digits
    for (int i = 0; i < len; i++) {
        char ch = *str++;
        if (ch < '0' || ch > '9') {
            dec_int = false;
            break;
        }
    }

    return dec_int;
}
