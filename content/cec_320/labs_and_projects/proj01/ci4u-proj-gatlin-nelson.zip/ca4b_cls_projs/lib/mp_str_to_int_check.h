#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdbool.h>

bool is_bin_int(char *str);
bool is_dec_int(char *str);
bool is_hex_int(char *str);
bool is_oct_int(char *str);

#ifdef __cplusplus
}
#endif /* __cplusplus */
