#include <stdbool.h>
#include <string.h>
#include "mp_uart_redirect.h"
#include "mp_str_to_int_conversion.h"

// Convert a string of binary integer to number 
int bin_str_to_int(char *str) {
    printf("Binary string conversion is not implemented yet\n");
    return -1;
}

// Convert a string of decimal integer to number 
int dec_str_to_int(char *str) {
    // Remove leading spaces
    while (*str == ' ') { 
        str++;
    }

    int sign = 1;
    // Check negative sign
    if (*str == '-') { 
        sign = -1;
        str++;
    }

    // Convert backward to avoid the leading 0 or spaces.
    int len = strlen(str);
    int num = 0;

    for (int i = len-1; i >= 0; i--) {
        int digit_val = *(str+i) - '0';
        num = num * 10 + digit_val;
    }

    return num * sign;
}

// Convert a string of decimal integer to number 
int hex_str_to_int(char *str) {
    // Remove leading spaces
    while (*str == ' ') { 
        str++;
    }

    int sign = 1;
    // Check negative sign
    if (*str == '-') { 
        sign = -1;
        str++;
    }

    // Remove spaces after '-'
    while (*str == ' ') { 
        str++;
    }

    // Convert backward to avoid the leading 0 or spaces.
    int len = strlen(str);
    int num = 0;
    int digit_val = 0;

    for (int i = len-1; i >= 2; i--) { // 2 is used here to avoid 0x.
        char ch = *(str+i);
        if ('0' <= ch && ch <= '9') {
            digit_val = ch - '0';
        } else if ('a' <= ch && ch <= 'f') {
            digit_val = ch - 'a' + 10;
        } else if ('A' <= ch && ch <= 'F') {
            digit_val = ch - 'A' + 10;
        }
        num = (num << 4) + digit_val;
    }

    return num * sign;
}

// Convert a string of octal integer to number 
int oct_str_to_int(char *str) {
    printf("Octal string conversion is not implemented yet\n");
    return -1;
}
