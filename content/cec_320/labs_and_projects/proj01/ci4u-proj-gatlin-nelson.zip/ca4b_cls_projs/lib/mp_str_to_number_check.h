#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdbool.h>

bool is_dec_int_num(char *str);

#ifdef __cplusplus
}
#endif /* __cplusplus */
