#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include <stdio.h>

// Print M-word unsigned number in hexadecimal
void mp_print_m_word(char operator, uint32_t m_word[], int M);

#ifdef __cplusplus
}
#endif /* __cplusplus */
