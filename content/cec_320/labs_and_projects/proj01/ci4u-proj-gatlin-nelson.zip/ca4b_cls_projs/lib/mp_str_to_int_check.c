#include <stdbool.h>
#include <string.h>
#include "mp_uart_redirect.h"
#include "mp_str_to_int_check.h"


bool is_bin_int(char *str) {
    // Remove leading spaces
    printf("Binary string checking is not implemented yet\n");
    return false;
}

// Check if this is a string of decimal integer. 
// Constraints for string:
//   1. Can have leading spaces.
//   2. Have have negative sign. 
//   3. Cannot have space after negative sign.
// Return false for the following cases:
//   1. String has any alphabet letter.
//   2. If spaces follow negative sign.
//   3. If 0 is the leading char except negative sign (an octal).
bool is_dec_int(char *str) {
    // Remove leading spaces
    while (*str == ' ') { 
        str++;
    }

    // Check negative sign
    if (*str == '-') { 
        str++;
    }

    // Check if 0 is the leading 0 for oct
    int len = strlen(str);
    if (*str == '0' && len > 1) { 
        return false;
    }

    bool dec_int = true;
    // Check other digits
    for (int i = 0; i < len; i++) {
        char ch = *str++;
        if (ch < '0' || ch > '9') {
            dec_int = false;
            break;
        }
    }

    return dec_int;
}

// Check if this is a string of decimal integer. 
// Constraints for string:
//   1. Can have leading spaces.
//   2. Have have negative sign. 
//   3. Cannot have space after negative sign.
// Return false for the following cases:
//   1. String does not have leading 0x
//   2. String has any alphabet letter other than `a` to `f`.
//   3. If spaces follow negative sign.
bool is_hex_int(char *str) {
    // Remove leading spaces
    while (*str == ' ') { 
        str++;
    }

    // Check negative sign
    if (*str == '-') { 
        str++;
    }

    // Check if 0x is present
    if (*str++ != '0') { 
        return false;
    }
    if (*str++ != 'x') { 
        return false;
    }

    int len = strlen(str);
    // Check other digits
    for (int i = 0; i < len; i++) {
        char ch = *str++;
        if (('0' <= ch && ch <= '9') || ('a' <= ch && ch <= 'f')) {
            // do nothing
        } else {
            return false;
        }
    }

    return true;
}

bool is_oct_int(char *str) {
    // Remove leading spaces
    printf("Octal string checking is not implemented yet\n");
    return false;
}
