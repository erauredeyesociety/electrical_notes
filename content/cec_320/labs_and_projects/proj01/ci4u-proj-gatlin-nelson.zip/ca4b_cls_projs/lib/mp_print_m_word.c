#include "mp_print_m_word.h"

/*
Print M-word unsigned number in hexadecimal
void mp_print_m_word(char operator, uint32_t m_word[], int M)

Input: 
  - char operator: a single char used to indicate the operator
  - uint32_t m_word[]: an array holding the M-word number. LSW is m_word[0].
  - int M: number of words in the m_word array.
Output: none except printf output.
*/
void mp_print_m_word(char operator, uint32_t m_word[], int M) {
    uint16_t halfword_low  = (uint16_t)m_word[M-1];
    uint16_t halfword_high = (uint16_t)(m_word[M-1] >> 16);
    printf("%c   0x%04X_%04X", operator, halfword_high, halfword_low);

    for (int i = M-2; i >= 0; i--) {
        halfword_low  = (uint16_t)m_word[i];
        halfword_high = (uint16_t)(m_word[i] >> 16);
        printf("__%04X_%04X", halfword_high, halfword_low);
    }
    printf("\n");
}
