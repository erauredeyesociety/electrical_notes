#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdbool.h>

int bin_str_to_int(char *str);
int dec_str_to_int(char *str);
int hex_str_to_int(char *str);
int oct_str_to_int(char *str);

#ifdef __cplusplus
}
#endif /* __cplusplus */
