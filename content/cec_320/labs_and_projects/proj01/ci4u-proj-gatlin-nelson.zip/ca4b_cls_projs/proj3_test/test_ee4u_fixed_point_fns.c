#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "unity.h"
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "ee4u_fixed_point_fns.h"

void test_mp_uq_and_q_mn_decoding(void) {
    // Case 1: Example 3 of Lctr 13
    // Case 2: Example 5 of Lctr 13
    uint32_t D = 0xAD;
    float exp_f[2] = {21.625, -10.375};
    float act_f[2];

    act_f[0] = mp_uq_and_q_mn_decoding(D, 0, 5, 3);
    act_f[1] = mp_uq_and_q_mn_decoding(D, 1, 4, 3);

    TEST_ASSERT_EQUAL_FLOAT_ARRAY(exp_f, act_f, 2);
}

void test_mp_uq_and_q_mn_encoding(void) {
    float f1 = 3.141593;  // Case 1: Example 4 of Lctr 13
    float f2 = -3.1234;   // Case 2: Example 7 of Lctr 13
    uint32_t exp_D[2] = {0x3244, 0xFFFFF382};
    uint32_t act_D[2];

    act_D[0] = mp_uq_and_q_mn_encoding(f1, 0, 4, 12);
    act_D[1] = mp_uq_and_q_mn_encoding(f2, 1, 5, 10);

    TEST_ASSERT_EQUAL_UINT32_ARRAY(exp_D, act_D, 2);
}

void test_mp_q_mn_multiplication(void) {
    float f1 = 0.5, f2 = 0.25;
    float exp_p = 0.125;
    float act_p = mp_q_mn_multiplication(f1, f2, 0, 15);
    TEST_ASSERT_EQUAL_FLOAT(exp_p, act_p);
}


void mp_unity(void) {
    printf("\n Running ee5a unit test:---\n\n");

    UNITY_BEGIN();

    RUN_TEST(test_mp_uq_and_q_mn_decoding);
    RUN_TEST(test_mp_uq_and_q_mn_encoding);
    RUN_TEST(test_mp_q_mn_multiplication);

    UNITY_END();
}
