#include <stdio.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "fi4b_bit_reversal_fns.h"
#include "mp_binary_str.h"


void mp_app(void) {
    printf("\n\nRunning fi4b main App-----------------\n");
    printf("\nBit Reversal:\n");

    uint32_t num = 0x5D;  // A = 0b1101_1101

    uint32_t rev8 = mp_bit_reverse_8_bit_fast_s(num);
    printf("Last 8 bits of num is: ");
    print_num_in_vrbs_bin_newln(num, 8);
    printf("Last 8 bits of rev8 is: ");
    print_num_in_vrbs_bin_newln(rev8, 8);

    uint32_t rev16 = mp_bit_reverse_16_bit_fast_s(num);
    printf("Last 16 bits of num is: ");
    print_num_in_vrbs_bin_newln(num, 16);
    printf("Last 16 bits of rev16 is: ");
    print_num_in_vrbs_bin_newln(rev16, 16);

    while (1);
}
