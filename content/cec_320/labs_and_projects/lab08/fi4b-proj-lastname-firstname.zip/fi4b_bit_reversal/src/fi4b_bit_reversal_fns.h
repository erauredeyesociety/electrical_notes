#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include <math.h>

uint32_t mp_bit_reverse_n_bit_naive_c(uint32_t x, int n);
uint8_t  mp_bit_reverse_8_bit_fast_c(uint8_t x);
uint16_t mp_bit_reverse_16_bit_fast_c(uint16_t x);
uint32_t mp_bit_reverse_32_bit_swar_c(uint32_t x);

uint32_t mp_bit_reverse_n_bit_naive_s(uint32_t x, int n);
uint8_t  mp_bit_reverse_8_bit_fast_s(uint8_t x);
uint16_t mp_bit_reverse_16_bit_fast_s(uint16_t x);

#ifdef __cplusplus
}
#endif /* __cplusplus */
