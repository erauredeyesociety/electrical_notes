#include "mp_uart_redirect.h"
#include "fi4b_bit_reversal_fns.h"
#include <stdint.h>


uint32_t mp_bit_reverse_n_bit_naive_c(uint32_t x, int n) {
    // Make sure n is between 2 and 32.
    int j = n - 1;
    for (int i = 0; i < n/2; i++, j--) {
        uint32_t mask_i = 1U << i;
        uint32_t mask_j = 1U << j;
        uint32_t b_i = (x >> i) & 1U;
        uint32_t b_j = (x >> j) & 1U;
        x &= ~(mask_i | mask_j);
        x |= (b_i << j) | (b_j << i);
    }
    return x;
}

uint8_t mp_bit_reverse_8_bit_fast_c(uint8_t x) {
    uint32_t y = 0x55;
    // x = (((x >> 1) & y) | ((x & y) << 1));
    uint32_t z = y & (x >> 1);
    x &= y;
    x = z | (x << 1);

    y = 0x33;
    // x = (((x >> 2) & y) | ((x & y) << 2));
    z = y & (x >> 2);
    x &= y;
    x = z | (x << 2);

    z = x >> 4;
    x = z | (x << 4);

    return x;
}

uint16_t mp_bit_reverse_16_bit_fast_c(uint16_t x) {
    uint32_t y = 0x5555;
    // x = (((x >> 1) & y) | ((x & y) << 1));
    uint32_t z = y & (x >> 1);
    x &= y;
    x = z | (x << 1);

    y = 0x3333;
    // x = (((x >> 2) & y) | ((x & y) << 2));
    z = y & (x >> 2);
    x &= y;
    x = z | (x << 2);

    y = 0x0f0f;
    // x = (((x >> 4) & y) | ((x & y) << 4));
    z = y & (x >> 4);
    x &= y;
    x = z | (x << 4);

    z = x >> 8;
    x = z | (x << 8);

    return x;
}

uint32_t mp_bit_reverse_32_bit_swar_c(uint32_t x) {
    uint32_t y = 0x55555555;
    x = (((x >> 1) & y) | ((x & y) << 1));
    y = 0x33333333;
    x = (((x >> 2) & y) | ((x & y) << 2));
    y = 0x0f0f0f0f;
    x = (((x >> 4) & y) | ((x & y) << 4));
    y = 0x00ff00ff;
    x = (((x >> 8) & y) | ((x & y) << 8));
    return ((x >> 16) | (x << 16));
}
