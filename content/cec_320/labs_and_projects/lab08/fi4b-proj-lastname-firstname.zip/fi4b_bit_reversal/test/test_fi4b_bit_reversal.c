#include <stdio.h>
#include <stdint.h>
#include "unity.h"
#include "fi4b_bit_reversal_fns.h"

// 32-bit test results

void test_reverse_32bits_in_0xDD_with_n_bit_naive_c(void) {
    uint32_t A = 0xDD;  // A = 0b1101_1101
    uint32_t B = 0xBB000000;  // B = 0b1011_1011
    uint32_t act = mp_bit_reverse_n_bit_naive_c(A, 32);
    TEST_ASSERT_EQUAL_INT32(B, act);
}

void test_reverse_32bits_in_0xDD_with_32_bit_swar_c(void) {
    uint32_t A = 0xDD;  // A = 0b1101_1101
    uint32_t B = 0xBB000000;  // B = 0b1011_1011
    uint32_t act = mp_bit_reverse_32_bit_swar_c(A);
    TEST_ASSERT_EQUAL_INT32(B, act);
}

// Test results for 16 bits and less. Part I. C

void test_reverse_4bits_in_0x0D_with_n_bit_naive_c(void) {
    uint32_t A = 0x0D;  // A = 0b0000_1101
    uint32_t B = 0x0B;  // B = 0b0000_1011
    uint32_t act = mp_bit_reverse_n_bit_naive_c(A, 4);
    TEST_ASSERT_EQUAL_INT32(B, act);
}

void test_reverse_5bits_in_0x1D_with_n_bit_naive_c(void) {
    uint32_t A = 0x1D;  // A = 0b0001_1101
    uint32_t B = 0x17;  // B = 0b0001_0111
    uint32_t act = mp_bit_reverse_n_bit_naive_c(A, 5);
    TEST_ASSERT_EQUAL_INT32(B, act);
}

void test_reverse_5bits_in_0x1D_with_8_bit_fast_c(void) {
    uint8_t A = 0x1D;  // A = 0b0001_1101
    uint8_t B = 0x17;  // B = 0b0001_0111
    uint8_t act = mp_bit_reverse_8_bit_fast_c(A) >> 3;
    TEST_ASSERT_EQUAL_INT8(B, act);
}

void test_reverse_8bits_in_0xDD_with_8_bit_fast_c(void) {
    uint8_t A = 0xDD;  // A = 0b1101_1101
    uint8_t B = 0xBB;  // B = 0b1011_1011
    uint8_t act = mp_bit_reverse_8_bit_fast_c(A);
    TEST_ASSERT_EQUAL_INT8(B, act);
}

void test_reverse_8bits_in_0xDD_with_16_bit_fast_c(void) {
    uint8_t A = 0xDD;  // A = 0b1101_1101
    uint8_t B = 0xBB;  // B = 0b1011_1011
    uint8_t act = mp_bit_reverse_16_bit_fast_c(A) >> 8;
    TEST_ASSERT_EQUAL_INT8(B, act);
}

void test_reverse_16bits_in_0xDD_with_16_bit_fast_c(void) {
    uint16_t A = 0xDD;  // A = 0b1101_1101
    uint16_t B = 0xBB00;  // B = 0b1011_1011
    uint16_t act = mp_bit_reverse_16_bit_fast_c(A);
    TEST_ASSERT_EQUAL_INT16(B, act);
}

// Test results for 16 bits and less. Part II. asm

void test_reverse_4bits_in_0x0D_with_n_bit_naive_s(void) {
    uint32_t A = 0x0D;  // A = 0b0000_1101
    uint32_t B = 0x0B;  // B = 0b0000_1011
    uint32_t act = mp_bit_reverse_n_bit_naive_s(A, 4);
    TEST_ASSERT_EQUAL_INT32(B, act);
}

void test_reverse_5bits_in_0x1D_with_n_bit_naive_s(void) {
    uint32_t A = 0x1D;  // A = 0b0001_1101
    uint32_t B = 0x17;  // B = 0b0001_0111
    uint32_t act = mp_bit_reverse_n_bit_naive_s(A, 5);
    TEST_ASSERT_EQUAL_INT32(B, act);
}

void test_reverse_5bits_in_0x1D_with_8_bit_naive_s(void) {
    uint8_t A = 0x1D;  // A = 0b0001_1101
    uint8_t B = 0x17;  // B = 0b0001_0111
    uint8_t act = mp_bit_reverse_8_bit_fast_s(A) >> 3;
    TEST_ASSERT_EQUAL_INT8(B, act);
}

void test_reverse_8bits_in_0xDD_with_8_bit_naive_s(void) {
    uint8_t A = 0xDD;  // A = 0b1101_1101
    uint8_t B = 0xBB;  // B = 0b1011_1011
    uint8_t act = mp_bit_reverse_8_bit_fast_s(A);
    TEST_ASSERT_EQUAL_INT8(B, act);
}

void test_reverse_16bits_in_0xDD_with_16_bit_naive_s(void) {
    uint16_t A = 0xDD;  // A = 0b1101_1101
    uint16_t B = 0xBB00;  // B = 0b1011_1011
    uint16_t act = mp_bit_reverse_16_bit_fast_s(A);
    TEST_ASSERT_EQUAL_INT16(B, act);
}

void test_reverse_8bits_in_0xDD_with_16_bit_naive_s(void) {
    uint8_t A = 0xDD;  // A = 0b1101_1101
    uint8_t B = 0xBB;  // B = 0b1011_1011
    uint8_t act = mp_bit_reverse_16_bit_fast_s(A) >> 8;
    TEST_ASSERT_EQUAL_INT8(B, act);
}


void mp_unity(void) {
    printf("\n\nfi4b unit test-----------------\n");

    UNITY_BEGIN();

    RUN_TEST(test_reverse_32bits_in_0xDD_with_n_bit_naive_c);
    RUN_TEST(test_reverse_32bits_in_0xDD_with_32_bit_swar_c);

    RUN_TEST(test_reverse_4bits_in_0x0D_with_n_bit_naive_c);
    RUN_TEST(test_reverse_5bits_in_0x1D_with_n_bit_naive_c);

    RUN_TEST(test_reverse_5bits_in_0x1D_with_8_bit_fast_c);
    RUN_TEST(test_reverse_8bits_in_0xDD_with_8_bit_fast_c);

    RUN_TEST(test_reverse_8bits_in_0xDD_with_16_bit_fast_c);
    RUN_TEST(test_reverse_16bits_in_0xDD_with_16_bit_fast_c);

    RUN_TEST(test_reverse_4bits_in_0x0D_with_n_bit_naive_s);
    RUN_TEST(test_reverse_5bits_in_0x1D_with_n_bit_naive_s);

    RUN_TEST(test_reverse_5bits_in_0x1D_with_8_bit_naive_s);
    RUN_TEST(test_reverse_8bits_in_0xDD_with_8_bit_naive_s);

    RUN_TEST(test_reverse_8bits_in_0xDD_with_16_bit_naive_s);
    RUN_TEST(test_reverse_16bits_in_0xDD_with_16_bit_naive_s);

    UNITY_END();

    while (1);
}
