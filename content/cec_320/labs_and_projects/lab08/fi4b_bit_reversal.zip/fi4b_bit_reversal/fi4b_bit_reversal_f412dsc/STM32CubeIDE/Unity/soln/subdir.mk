################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
C:/proj_mp/fi4b_bit_reversal_soln/src_soln/fi4b_bit_reversal_sfns_soln.s 

OBJS += \
./soln/fi4b_bit_reversal_sfns_soln.o 

S_DEPS += \
./soln/fi4b_bit_reversal_sfns_soln.d 


# Each subdirectory must supply rules for building sources it contributes
soln/fi4b_bit_reversal_sfns_soln.o: C:/proj_mp/fi4b_bit_reversal_soln/src_soln/fi4b_bit_reversal_sfns_soln.s soln/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-soln

clean-soln:
	-$(RM) ./soln/fi4b_bit_reversal_sfns_soln.d ./soln/fi4b_bit_reversal_sfns_soln.o

.PHONY: clean-soln

