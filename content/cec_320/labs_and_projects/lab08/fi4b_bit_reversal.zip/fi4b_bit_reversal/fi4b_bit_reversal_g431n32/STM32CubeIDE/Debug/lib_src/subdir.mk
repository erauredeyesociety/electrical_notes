################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
C:/proj_mp/fi4b_bit_reversal/src/fi4b_bit_reversal_sfns.s 

C_SRCS += \
C:/proj_mp/fi4b_bit_reversal/src/_mp_main.c \
C:/proj_mp/fi4b_bit_reversal/src/fi4b_bit_reversal_app.c \
C:/proj_mp/fi4b_bit_reversal/src/fi4b_bit_reversal_cfns.c \
C:/proj_mp/fi4b_bit_reversal/lib/mp_binary_str.c \
C:/proj_mp/fi4b_bit_reversal/lib/mp_print_m_word.c \
C:/proj_mp/fi4b_bit_reversal/lib/mp_uart_redirect.c \
C:/proj_mp/fi4b_bit_reversal/test/test_fi4b_bit_reversal.c \
C:/proj_mp/fi4b_bit_reversal/lib/unity.c 

OBJS += \
./lib_src/_mp_main.o \
./lib_src/fi4b_bit_reversal_app.o \
./lib_src/fi4b_bit_reversal_cfns.o \
./lib_src/fi4b_bit_reversal_sfns.o \
./lib_src/mp_binary_str.o \
./lib_src/mp_print_m_word.o \
./lib_src/mp_uart_redirect.o \
./lib_src/test_fi4b_bit_reversal.o \
./lib_src/unity.o 

S_DEPS += \
./lib_src/fi4b_bit_reversal_sfns.d 

C_DEPS += \
./lib_src/_mp_main.d \
./lib_src/fi4b_bit_reversal_app.d \
./lib_src/fi4b_bit_reversal_cfns.d \
./lib_src/mp_binary_str.d \
./lib_src/mp_print_m_word.d \
./lib_src/mp_uart_redirect.d \
./lib_src/test_fi4b_bit_reversal.d \
./lib_src/unity.d 


# Each subdirectory must supply rules for building sources it contributes
lib_src/_mp_main.o: C:/proj_mp/fi4b_bit_reversal/src/_mp_main.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/fi4b_bit_reversal_app.o: C:/proj_mp/fi4b_bit_reversal/src/fi4b_bit_reversal_app.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/fi4b_bit_reversal_cfns.o: C:/proj_mp/fi4b_bit_reversal/src/fi4b_bit_reversal_cfns.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/fi4b_bit_reversal_sfns.o: C:/proj_mp/fi4b_bit_reversal/src/fi4b_bit_reversal_sfns.s lib_src/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"
lib_src/mp_binary_str.o: C:/proj_mp/fi4b_bit_reversal/lib/mp_binary_str.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/mp_print_m_word.o: C:/proj_mp/fi4b_bit_reversal/lib/mp_print_m_word.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/mp_uart_redirect.o: C:/proj_mp/fi4b_bit_reversal/lib/mp_uart_redirect.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/test_fi4b_bit_reversal.o: C:/proj_mp/fi4b_bit_reversal/test/test_fi4b_bit_reversal.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/unity.o: C:/proj_mp/fi4b_bit_reversal/lib/unity.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lib_src

clean-lib_src:
	-$(RM) ./lib_src/_mp_main.cyclo ./lib_src/_mp_main.d ./lib_src/_mp_main.o ./lib_src/_mp_main.su ./lib_src/fi4b_bit_reversal_app.cyclo ./lib_src/fi4b_bit_reversal_app.d ./lib_src/fi4b_bit_reversal_app.o ./lib_src/fi4b_bit_reversal_app.su ./lib_src/fi4b_bit_reversal_cfns.cyclo ./lib_src/fi4b_bit_reversal_cfns.d ./lib_src/fi4b_bit_reversal_cfns.o ./lib_src/fi4b_bit_reversal_cfns.su ./lib_src/fi4b_bit_reversal_sfns.d ./lib_src/fi4b_bit_reversal_sfns.o ./lib_src/mp_binary_str.cyclo ./lib_src/mp_binary_str.d ./lib_src/mp_binary_str.o ./lib_src/mp_binary_str.su ./lib_src/mp_print_m_word.cyclo ./lib_src/mp_print_m_word.d ./lib_src/mp_print_m_word.o ./lib_src/mp_print_m_word.su ./lib_src/mp_uart_redirect.cyclo ./lib_src/mp_uart_redirect.d ./lib_src/mp_uart_redirect.o ./lib_src/mp_uart_redirect.su ./lib_src/test_fi4b_bit_reversal.cyclo ./lib_src/test_fi4b_bit_reversal.d ./lib_src/test_fi4b_bit_reversal.o ./lib_src/test_fi4b_bit_reversal.su ./lib_src/unity.cyclo ./lib_src/unity.d ./lib_src/unity.o ./lib_src/unity.su

.PHONY: clean-lib_src

