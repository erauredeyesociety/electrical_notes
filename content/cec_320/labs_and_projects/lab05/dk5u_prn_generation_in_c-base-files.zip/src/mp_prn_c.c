#include "mp_prn_c.h"
#include "mp_sum_of_1s.h"

int poly1[] = {3, 4};
int poly2[] = {3, 10};
int poly_n = 2;
uint32_t prn_reg;

static uint32_t reg_mask;   // mask to limit PRN register value
static uint32_t tap_mask;   // mask for taps (each tap is 1)

// Initializing the PRN register---dereferenced prn_reg
__attribute__((weak))
uint32_t mp_prn_ini_c(uint32_t *prn_reg, int *poly, int poly_n) {
    return reg_mask;
}

// Building the tap mask from poly and poly_n
__attribute__((weak))
uint32_t mp_prn_tap_mask_c(int *poly, int poly_n) {
    return tap_mask;
}

// Generating the output bit and updating prn_reg
__attribute__((weak))
bool mp_prn_gen_c(uint32_t *prn_reg) {
    return true;
}
