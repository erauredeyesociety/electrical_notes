#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "unity.h"
#include "mp_prn_c.h"

extern int poly1[];
extern int poly2[];
extern int poly_n;
extern uint32_t prn_reg;

//-----------------------------------------------
void test_prn_ini_c(void) {
    uint32_t exp[] = {0x000F, 0x03FF};
    uint32_t act[2];
    mp_prn_ini_c(&act[0], poly1, poly_n);
    mp_prn_ini_c(&act[1], poly2, poly_n);
    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}

//-----------------------------------------------
void test_prn_tap_mask_c(void) {
    uint32_t exp[] = {(1<<2) + (1<<3), (1<<2) + (1<<9)};
    uint32_t act[2];
    act[0] = mp_prn_tap_mask_c(poly1, poly_n);
    act[1] = mp_prn_tap_mask_c(poly2, poly_n);
    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 2);
}

//-----------------------------------------------
void test_prn_gen_for_prn_poly1_c(void) {
    uint8_t exp[] = {1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0};
    uint8_t act[15];
    mp_prn_ini_c(&prn_reg, poly1, poly_n);
    mp_prn_tap_mask_c(poly1, poly_n);
    for (int i = 0; i < 15; i++) {
        act[i] = mp_prn_gen_c(&prn_reg);
    }
    TEST_ASSERT_EQUAL_INT8_ARRAY(exp, act, 15);
}

//-----------------------------------------------
void test_prn_gen_for_reg_poly1_c(void) {
    uint32_t exp[] =
            {0xE, 0xC, 8, 1, 2, 4, 9, 3, 6, 0xD, 0xA, 5, 0xB, 7, 0xF};
    uint32_t act[15];
    mp_prn_ini_c(&prn_reg, poly1, poly_n);
    mp_prn_tap_mask_c(poly1, poly_n);
    for (int i = 0; i < 15; i++) {
        mp_prn_gen_c(&prn_reg);
        act[i] = prn_reg;
    }
    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 15);
}

//-----------------------------------------------
void test_prn_gen_for_prn_poly2_c(void) {
    uint8_t exp[] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1};
    uint8_t act[15];
    mp_prn_ini_c(&prn_reg, poly2, poly_n);
    mp_prn_tap_mask_c(poly2, poly_n);
    for (int i = 0; i < 15; i++) {
        act[i] = mp_prn_gen_c(&prn_reg);
    }
    TEST_ASSERT_EQUAL_INT8_ARRAY(exp, act, 15);
}

//-----------------------------------------------
void test_prn_gen_for_reg_poly2_c(void) {
    uint32_t exp[] =
            {0x3FE, 0x3FC, 0x3F8, 0x3F1, 0x3E3, 0x3C7, 0x38E,
            0x31C, 0x238, 0x71, 0xE2, 0x1C4, 0x389, 0x313, 0x227};
    uint32_t act[15];
    mp_prn_ini_c(&prn_reg, poly2, poly_n);
    mp_prn_tap_mask_c(poly2, poly_n);
    for (int i = 0; i < 15; i++) {
        mp_prn_gen_c(&prn_reg);
        act[i] = prn_reg;
    }
    TEST_ASSERT_EQUAL_INT32_ARRAY(exp, act, 15);
}


void mp_unity(void) {
    UNITY_BEGIN();

    RUN_TEST(test_prn_ini_c);
    RUN_TEST(test_prn_tap_mask_c);

    RUN_TEST(test_prn_gen_for_prn_poly1_c);
    RUN_TEST(test_prn_gen_for_reg_poly1_c);

    RUN_TEST(test_prn_gen_for_prn_poly2_c);
    RUN_TEST(test_prn_gen_for_reg_poly2_c);

    UNITY_END();

    while (1);
}
