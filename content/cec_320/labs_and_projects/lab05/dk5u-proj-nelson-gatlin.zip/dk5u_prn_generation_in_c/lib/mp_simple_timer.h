#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdio.h>
#if defined(STM32F412Zx) || defined(STM32G431xx) 
    extern TIM_HandleTypeDef    htim4;
    #define HTIM                htim4
    #define TIM_IRQn            TIM4_IRQn
// #elif defined(STM32L476xx) || defined(STM32L432xx)
//     #include "stm32l4xx_hal.h" 
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */
