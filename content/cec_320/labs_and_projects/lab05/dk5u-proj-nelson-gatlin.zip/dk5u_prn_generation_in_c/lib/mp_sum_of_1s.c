#include "mp_sum_of_1s.h"

// Find the sum of 1s in a word by the div-by-2 method:
int mp_sum_of_1s(uint32_t num) {
    int sum_of_1 = 0;
    while (num) {
        int b_i = num & 1U;
        sum_of_1 += b_i;
        num = num >> 1;
    }
    return sum_of_1;
}
