#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>

int mp_sum_of_1s(uint32_t num);

#ifdef __cplusplus
}
#endif /* __cplusplus */
