#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include <stdbool.h>

// Initializing the PRN register---dereferenced prn_reg
// The following are the input and output of the PRN functions:
//    Input:
//      uint32_t *prn_reg: the pointer of the PRN register.
//      int *poly: the polynomial values of the PRN generator.
//          For a given example, this is [3, 10]
//      int poly_n: the number of elements in poly[].
//    Output:
//      uint32_t reg_mask: the register mask
uint32_t mp_prn_ini_c(uint32_t *prn_reg, int *poly, int poly_n);

// Building the tap mask from poly and poly_n.
//    Output:
//      uint32_t tap_mask: the tap mask. For the example with poly [3, 10],
//          this tap mask is (1<<2) | (1<<9).
uint32_t mp_prn_tap_mask_c(int *poly, int poly_n);

// Generating the output bit and updating the PRN register---reg.
//    Output:
//      bool output: the output bit.
bool mp_prn_gen_c(uint32_t *prn_reg);

#ifdef __cplusplus
}
#endif /* __cplusplus */
