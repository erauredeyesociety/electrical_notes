#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "main.h"
#include "mp_uart_redirect.h"
#include "dk5u_timer_fns.h"
#include "mp_simple_timer.h"
#include "mp_prn_c.h"


#define CRG_RETURN 13   // ASCII code for carriage return

// Callback for UARTs
// - Only handles UART2
typedef enum {
    STATE_INI = 0,      // Initial state
    STATE_NORMAL,
} state_t;

static state_t state = STATE_INI;

uint16_t PSC_val;
extern uint8_t uart2_rxBuffer[];

char msg_pmpt[] = "\nInput a number between %d and %d for PSC:\n";
char err_pmpt[] = "\nInput out of range.";
char cmd_core[] = "               ";
int min_PSC = 100;
int max_PSC = 10000;
int i = 0;

extern int poly2[];
extern int poly_n;
extern uint32_t prn_reg;

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (state == STATE_INI) {
        state = STATE_NORMAL;
        printf(msg_pmpt, min_PSC, max_PSC);
        HAL_UART_Receive_IT(&huart2, uart2_rxBuffer, 1);

        // Initialize the PRN and Timer
        mp_prn_ini_c(&prn_reg, poly2, poly_n);
        mp_prn_tap_mask_c(poly2, poly_n);
        HAL_TIM_Base_Start_IT(&HTIM);

        return;
    }

    uint8_t new_input = uart2_rxBuffer[0];
    if (new_input >= '0' && new_input <= '9') {
        cmd_core[i++] = new_input;
        HAL_UART_Transmit(&huart2, &new_input, 1, 1000);
    } else if (new_input == CRG_RETURN) {
        cmd_core[i] = 0;
        PSC_val = atoi(cmd_core);
        if (PSC_val >= min_PSC && PSC_val <= max_PSC) {
            mp_set_timer_prescaler(PSC_val);
        } else {
            printf("%s", err_pmpt);
        }
        i = 0;
        printf(msg_pmpt, min_PSC, max_PSC);
    }

    HAL_UART_Receive_IT(&huart2, uart2_rxBuffer, 1);
}
