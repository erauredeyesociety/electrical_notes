#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "stdint.h"

void mp_set_timer_prescaler(uint16_t PSC_value);
void mp_TIM_Callback(void); 

#ifdef __cplusplus
}
#endif /* __cplusplus */
