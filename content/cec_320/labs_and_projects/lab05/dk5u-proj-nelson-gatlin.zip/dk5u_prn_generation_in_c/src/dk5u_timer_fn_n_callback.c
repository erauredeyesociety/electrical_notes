#include <stdbool.h>
#include <main.h>
#include "mp_supported_mcu.h"
#include "mp_simple_timer.h"
#include "mp_prn_c.h"

extern uint32_t prn_reg;

void mp_set_timer_prescaler(uint16_t PSC_value) {
    __HAL_TIM_SET_PRESCALER(&HTIM, PSC_value);
}

// Callback function for a timer:
void mp_TIM_Callback(void) {
    bool LED_state = mp_prn_gen_c(&prn_reg);
    HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin, LED_state);
}
