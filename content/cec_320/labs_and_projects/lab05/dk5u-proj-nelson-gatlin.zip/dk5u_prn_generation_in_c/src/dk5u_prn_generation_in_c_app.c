#include <stdlib.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"


uint8_t uart2_rxBuffer[10];

void mp_app(void) {
    printf("\ndk5u App starts here:---\n\n");

    HAL_UART_Receive_IT(&huart2, uart2_rxBuffer, 1); // Read 1 byte only
    printf("Press any key to continue:\n");

    while (1);
}
