################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/proj_mp/de2f_direct_gpio_reg_access/src/_mp_main.c \
C:/proj_mp/de2f_direct_gpio_reg_access/src/de2f_direct_gpio_reg_access.c \
C:/proj_mp/de2f_direct_gpio_reg_access/src/de2f_direct_gpio_reg_access_app.c \
C:/proj_mp/de2f_direct_gpio_reg_access/src/de2f_systick_callbacks.c \
C:/proj_mp/de2f_direct_gpio_reg_access/lib/mp_uart_redirect.c 

OBJS += \
./lib_src/_mp_main.o \
./lib_src/de2f_direct_gpio_reg_access.o \
./lib_src/de2f_direct_gpio_reg_access_app.o \
./lib_src/de2f_systick_callbacks.o \
./lib_src/mp_uart_redirect.o 

C_DEPS += \
./lib_src/_mp_main.d \
./lib_src/de2f_direct_gpio_reg_access.d \
./lib_src/de2f_direct_gpio_reg_access_app.d \
./lib_src/de2f_systick_callbacks.d \
./lib_src/mp_uart_redirect.d 


# Each subdirectory must supply rules for building sources it contributes
lib_src/_mp_main.o: C:/proj_mp/de2f_direct_gpio_reg_access/src/_mp_main.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/de2f_direct_gpio_reg_access.o: C:/proj_mp/de2f_direct_gpio_reg_access/src/de2f_direct_gpio_reg_access.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/de2f_direct_gpio_reg_access_app.o: C:/proj_mp/de2f_direct_gpio_reg_access/src/de2f_direct_gpio_reg_access_app.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/de2f_systick_callbacks.o: C:/proj_mp/de2f_direct_gpio_reg_access/src/de2f_systick_callbacks.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/mp_uart_redirect.o: C:/proj_mp/de2f_direct_gpio_reg_access/lib/mp_uart_redirect.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lib_src

clean-lib_src:
	-$(RM) ./lib_src/_mp_main.cyclo ./lib_src/_mp_main.d ./lib_src/_mp_main.o ./lib_src/_mp_main.su ./lib_src/de2f_direct_gpio_reg_access.cyclo ./lib_src/de2f_direct_gpio_reg_access.d ./lib_src/de2f_direct_gpio_reg_access.o ./lib_src/de2f_direct_gpio_reg_access.su ./lib_src/de2f_direct_gpio_reg_access_app.cyclo ./lib_src/de2f_direct_gpio_reg_access_app.d ./lib_src/de2f_direct_gpio_reg_access_app.o ./lib_src/de2f_direct_gpio_reg_access_app.su ./lib_src/de2f_systick_callbacks.cyclo ./lib_src/de2f_systick_callbacks.d ./lib_src/de2f_systick_callbacks.o ./lib_src/de2f_systick_callbacks.su ./lib_src/mp_uart_redirect.cyclo ./lib_src/mp_uart_redirect.d ./lib_src/mp_uart_redirect.o ./lib_src/mp_uart_redirect.su

.PHONY: clean-lib_src

