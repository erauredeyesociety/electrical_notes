#include "main.h"
#include "de2f_direct_gpio_reg_access.h"

// In stm32g4xx_hal.c, HAL_IncTick is defined a weak function as follows:
// __weak void HAL_IncTick(void)
// {
//   uwTick += uwTickFreq;
// }
// It will be replaced by the following user-defined callback function:

// Callback function for SysTick timer:
extern __IO uint32_t uwTick;
extern uint32_t uwTickFreq;
int time_to_toggle = 2000; // Two seconds

void HAL_IncTick(void) {
    uwTick += uwTickFreq;
    if (uwTick % time_to_toggle == 0) {
        mp_toggle_LEDs();
    }
}
