#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdbool.h>

void mp_Fnc6_init(void);
void mp_LED1_init(void);

void mp_toggle_LEDs(void);

bool mp_read_Fnc6(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */
