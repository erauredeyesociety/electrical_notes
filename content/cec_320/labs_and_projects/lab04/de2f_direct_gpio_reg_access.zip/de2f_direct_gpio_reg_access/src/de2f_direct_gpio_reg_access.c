#include "main.h"
#include "de2f_direct_gpio_reg_access.h"


// Initialization functions for GPIO pins:

// Initialize GPIO input for Fnc6, connected to PA0 for the following boards:
// -   G431n32
// -   L412n32

void mp_Fnc6_init(void) {
    // MODER: PA0 = input, value = 0b00:
    GPIOA->MODER &= ~(3U << 0 * 2);

    // OTYPER: N/A
    // OSPEEDR: N/A

    // PUPDR: PA0 = pull-down, value = 0b10
    GPIOA->PUPDR &= ~(3U << 0 * 2);
    GPIOA->PUPDR |= (2U << 0 * 2);
}

// Initialize GPIO output for LED1, connected to PA10 for the following boards:
// -   G431n32
// -   L412n32

void mp_LED1_init(void) {
    // MODER: PA10 = output, value = 0b01:
    GPIOA->MODER &= ~(3U << 10 * 2);
    GPIOA->MODER |= (1U << 10 * 2);

    // OTYPER: PA10 = push-pull, value = 0b0, which is default. Use default.

    // OSPEEDR: Use default
    // PUPDR: Use default
}

// Functions for accessing GPIO pins:
uint32_t mask_Pin0 = 0x0001U;  // 1U << 0
uint32_t mask_Pin10 = 0x0400U; // 1U << 10
uint32_t mask_Pin8 = 0x0100U; // 1U << 8

void mp_toggle_LEDs(void) {
    GPIOA->ODR ^= mask_Pin10;
    GPIOB->ODR ^= mask_Pin8;
}

bool mp_read_Fnc6(void) {
    return (GPIOA->IDR & mask_Pin0) > 0;
}
