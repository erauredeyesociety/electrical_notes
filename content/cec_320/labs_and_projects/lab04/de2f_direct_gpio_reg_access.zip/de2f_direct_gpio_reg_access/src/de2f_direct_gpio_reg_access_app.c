#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "de2f_direct_gpio_reg_access.h"

char cmd_str[50];
int8_t pin_val = 0;

void mp_app(void) {
    printf("\n Running de2f_direct_gpio_reg_access:---------------\n\n");

    mp_Fnc6_init();
    mp_LED1_init();

    SET_STDIN_TO_NO_BUFFER;
    while (1) {
        printf("Input 'g' to get the value of input pin (LED4): \n");
        scanf("%s", cmd_str);
        if (cmd_str[0] == 'g' && cmd_str[1] == 0) {
            pin_val = mp_read_Fnc6();
            printf("Value of the pin = %d.\n", pin_val);
        }
    }
}
