#include "main.h"
#include "de5d_logic_analyzer_fns.h"

// Callback function for SysTick timer:
extern __IO uint32_t uwTick;
extern uint32_t uwTickFreq;
int time_to_toggle = 2000; // Two seconds

void HAL_IncTick(void) {
    uwTick += uwTickFreq;
    if (uwTick % time_to_toggle == 0) {
        mp_toggle_LEDs();
    }
}
