#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define CHANNELS 3
#define SAMPLES 50

void mp_Fnc6_init(void);
void mp_LED1_init(void);

void mp_init_set_LED1_reset_LED4(void);

void mp_toggle_LEDs(void);

void mp_read_logic_samples(void);
void mp_print_logic_samples(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */
