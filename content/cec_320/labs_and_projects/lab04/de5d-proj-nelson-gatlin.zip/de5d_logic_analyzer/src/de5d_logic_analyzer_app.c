#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "de5d_logic_analyzer_fns.h"

char cmd_str[50];

void mp_app(void) {
    printf("\n Running de5d Logic Analyzer App:--------------\n\n");

    mp_Fnc6_init();
    mp_LED1_init();
    mp_init_set_LED1_reset_LED4();

    SET_STDIN_TO_NO_BUFFER;
    while (1) {
        printf("Input 's' to sample logic levels: \n");
        scanf("%s", cmd_str);
        if (cmd_str[0] == 's' && cmd_str[1] == 0) {
            printf("Sampling data for you...just a moment.\n");
            mp_read_logic_samples();
            mp_print_logic_samples();
        }
    }
}
