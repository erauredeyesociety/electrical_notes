################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/opt/proj_mp/de5d_logic_analyzer/src/_mp_main.c \
/opt/proj_mp/de5d_logic_analyzer/src/de5d_callbacks.c \
/opt/proj_mp/de5d_logic_analyzer/src/de5d_logic_analyzer_app.c \
/opt/proj_mp/de5d_logic_analyzer/src/de5d_logic_analyzer_fns.c \
/opt/proj_mp/de5d_logic_analyzer/lib/mp_uart_redirect.c 

OBJS += \
./lab_src/_mp_main.o \
./lab_src/de5d_callbacks.o \
./lab_src/de5d_logic_analyzer_app.o \
./lab_src/de5d_logic_analyzer_fns.o \
./lab_src/mp_uart_redirect.o 

C_DEPS += \
./lab_src/_mp_main.d \
./lab_src/de5d_callbacks.d \
./lab_src/de5d_logic_analyzer_app.d \
./lab_src/de5d_logic_analyzer_fns.d \
./lab_src/mp_uart_redirect.d 


# Each subdirectory must supply rules for building sources it contributes
lab_src/_mp_main.o: /opt/proj_mp/de5d_logic_analyzer/src/_mp_main.c lab_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lab_src/de5d_callbacks.o: /opt/proj_mp/de5d_logic_analyzer/src/de5d_callbacks.c lab_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lab_src/de5d_logic_analyzer_app.o: /opt/proj_mp/de5d_logic_analyzer/src/de5d_logic_analyzer_app.c lab_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lab_src/de5d_logic_analyzer_fns.o: /opt/proj_mp/de5d_logic_analyzer/src/de5d_logic_analyzer_fns.c lab_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lab_src/mp_uart_redirect.o: /opt/proj_mp/de5d_logic_analyzer/lib/mp_uart_redirect.c lab_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../../Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc -I../../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lab_src

clean-lab_src:
	-$(RM) ./lab_src/_mp_main.cyclo ./lab_src/_mp_main.d ./lab_src/_mp_main.o ./lab_src/_mp_main.su ./lab_src/de5d_callbacks.cyclo ./lab_src/de5d_callbacks.d ./lab_src/de5d_callbacks.o ./lab_src/de5d_callbacks.su ./lab_src/de5d_logic_analyzer_app.cyclo ./lab_src/de5d_logic_analyzer_app.d ./lab_src/de5d_logic_analyzer_app.o ./lab_src/de5d_logic_analyzer_app.su ./lab_src/de5d_logic_analyzer_fns.cyclo ./lab_src/de5d_logic_analyzer_fns.d ./lab_src/de5d_logic_analyzer_fns.o ./lab_src/de5d_logic_analyzer_fns.su ./lab_src/mp_uart_redirect.cyclo ./lab_src/mp_uart_redirect.d ./lab_src/mp_uart_redirect.o ./lab_src/mp_uart_redirect.su

.PHONY: clean-lab_src

