#include "mp_mock_odr_update_with_bsrr_brr.h"

__attribute__((weak))
void mp_mock_odr_update_with_bsrr(GPIO_TypeDef *GPIOx) {

}
