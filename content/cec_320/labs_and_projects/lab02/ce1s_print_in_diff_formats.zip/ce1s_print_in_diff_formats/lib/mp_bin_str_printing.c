#include <stdio.h>
#include <string.h>
#include "mp_bin_str_printing.h"


// Define two strings used locally: one compact and the other verbose:
// Examples: str_cmpt[] = "10111101", str_vrbs[] = "0b1011_1101".
static char str_cmpt[40], str_vrbs[50];
// Note that we can use these strings as arguments to functions; we can also
// use them as private variables that can be accessed directly by functions
// defined in this file.

// Use an n-bit mask to keep only the lowest n bits in an integer number.
// num: the number to convert.
// n: the number of bits for conversion.
static uint32_t mask_n_bits(uint32_t num, int n) {
    uint32_t n_bit_mask = (1U << n) - 1;    // 0b11 ... 11
    return num & n_bit_mask;                //   \-- n --/
}

// Convert an integer, num, to binary string by the div-by-2 method:
// Every pass in the loop, we divide the number by 2 and find the LSB
// (least significant bit), which should be 0 or 1. We add this value
// to '0' and save the addition to the appropriate location in string.
static void num_2_n_bit_bin_str_div_by_2(char *str, uint32_t num, int n) {
	num = mask_n_bits(num, n);
    int i = 0;  // index for the bit (or digit)
    while (num) {
        int b_i = num % 2;
        str[n - 1 - i++] = '0' + b_i;
        num = num / 2;
    }
    while (i < n) {
        str[n - 1 - i++] = '0';
    }
    str[n] = 0;
}

// Convert an integer, num, to binary string by the bit-scanning method:
// Every pass in the loop, we check one bit (scan) to see it is 1 or 0.
static void num_2_n_bit_bin_str_bit_scan(char *str, uint32_t num, int n) {
    num = mask_n_bits(num, n);
    for (int i = 0; i < n; i++) {   // i is used for bit index
        if (num & (1U << i)) {
            // write '1' at the right bit location.
            *(str + n - 1 - i) = '1';
        } else {
            *(str + n - 1 - i) = '0';
        }
    }
    *(str + n) = 0; // end the string.
}

// Convert an integer, num, to binary string by the shift-to-right method:
// This is very similar to div-by-2.
static void num_2_n_bit_bin_str_shift2rt(char *str, uint32_t num, int n) {
    num = mask_n_bits(num, n);
    for (int i = 0; i < n; i++) {  // i for bit index
        int b_i = (num >> i) & 1U;
        *(str + n - 1 - i) = '0' + b_i;
    }
    *(str + n) = 0; // end the string.
}

// Public functions--------------------------------------

// A wrapper function for easy usage:
// Convert an integer, num, to binary string by the shift 2 right method:
// para: str---the string to save the result
// para: num---the number to convert to binary
// para: n---the number of bits to convert
void mp_bin_num_2_n_bit_cmpt_bin_str(char *str, uint32_t num, int n) {
    num_2_n_bit_bin_str_shift2rt(str, num, n);
}

// A wrapper function for easy usage:
void mp_bin_num_2_n_bit_vrbs_bin_str(char *str, uint32_t num, int n) {
    // Convert the number to a compact string.
    num_2_n_bit_bin_str_shift2rt(str_cmpt, num, n);

    int padded_nbits = n;
    if (n % 4) {
        padded_nbits = 4 + ((n >> 2) << 2);
    }

    char *mstr_cmpt = str_cmpt;  // define mutable string pointers
    char *mstr_vrbs = str;

    // Build the prefix:
    mstr_vrbs = strcpy(mstr_vrbs, "0b") + 2;

    // Pad '0' at the MSB if needed
    int to_pad = padded_nbits - n;
    if (to_pad) {
        for (int i = 0; i < to_pad; i++) {
            *mstr_vrbs++ = '0';
        }
        mstr_vrbs = strncpy(mstr_vrbs, mstr_cmpt, 4-to_pad) + 4 - to_pad;
        mstr_cmpt += 4 - to_pad;
        n -= 4 - to_pad;
        *mstr_vrbs++ = '_';
    }

    // Copy in groups of 4 bits
    for (int i = 0; i < n>>2; i++) {
        mstr_vrbs = strncpy(mstr_vrbs, mstr_cmpt, 4) + 4;
        mstr_cmpt += 4;
        *mstr_vrbs++ = '_';
    }
    *--mstr_vrbs = 0;
}

// Print a number as a compact binary string without new line
void mp_bin_print_num_in_cmpt_bin(uint32_t num, int n) {
    mp_bin_num_2_n_bit_cmpt_bin_str(str_cmpt, num, n);
    printf("%s", str_cmpt);
}

// Print a number as a compact binary string with new line
void mp_bin_print_num_in_cmpt_bin_newln(uint32_t num, int n) {
    mp_bin_print_num_in_cmpt_bin(num, n) ;
    printf("\n");
}

void mp_bin_print_num_in_cmpt_bin_choice(uint32_t num, int n,
        num2bin_method_t n2b) {
    // Convert the number to a compact string.
    switch (n2b) {
    case N2B_DIV_BY_2:
        num_2_n_bit_bin_str_div_by_2(str_cmpt, num, n);
        break;
    case N2B_BIT_SCAN:
        num_2_n_bit_bin_str_bit_scan(str_cmpt, num, n);
        break;
    case N2B_SHIFT2RT:
        num_2_n_bit_bin_str_shift2rt(str_cmpt, num, n);
        break;
    default:
        printf("Wrong method for number to binary string conversion.\n");
    }

    printf("%s", str_cmpt);
}

// Print a number as a verbose binary string without new line
void mp_bin_print_num_in_vrbs_bin(uint32_t num, int n) {
    mp_bin_num_2_n_bit_vrbs_bin_str(str_vrbs, num, n);
    printf("%s", str_vrbs);
}

// Print a number as a verbose binary string with new line
void mp_bin_print_num_in_vrbs_bin_newln(uint32_t num, int n) {
    mp_bin_print_num_in_vrbs_bin(num, n);
    printf("\n");
}
