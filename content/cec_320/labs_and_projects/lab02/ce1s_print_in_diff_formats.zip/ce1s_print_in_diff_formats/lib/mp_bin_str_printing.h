#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

typedef enum {
    N2B_DIV_BY_2,
    N2B_BIT_SCAN,
    N2B_SHIFT2RT,
} num2bin_method_t;

void mp_bin_num_2_n_bit_cmpt_bin_str(char *str, uint32_t num, int n);

void mp_bin_num_2_n_bit_vrbs_bin_str(char *str, uint32_t num, int n);

void mp_bin_print_num_in_cmpt_bin(uint32_t num, int n);
void mp_bin_print_num_in_cmpt_bin_newln(uint32_t num, int n);
void mp_bin_print_num_in_cmpt_bin_choice(uint32_t num, int n,
        num2bin_method_t n2b);

void mp_bin_print_num_in_vrbs_bin(uint32_t num, int n);
void mp_bin_print_num_in_vrbs_bin_newln(uint32_t num, int n);

#ifdef __cplusplus
}
#endif
