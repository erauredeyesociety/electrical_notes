################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/proj_mp/ce1s_print_in_diff_formats/src/_mp_main.c \
C:/proj_mp/ce1s_print_in_diff_formats/src/ce1s_print_in_diff_formats_app.c \
C:/proj_mp/ce1s_print_in_diff_formats/lib/mp_bin_str_printing.c \
C:/proj_mp/ce1s_print_in_diff_formats/lib/mp_str_dec_number.c \
C:/proj_mp/ce1s_print_in_diff_formats/lib/mp_uart_redirect.c 

OBJS += \
./lib_src/_mp_main.o \
./lib_src/ce1s_print_in_diff_formats_app.o \
./lib_src/mp_bin_str_printing.o \
./lib_src/mp_str_dec_number.o \
./lib_src/mp_uart_redirect.o 

C_DEPS += \
./lib_src/_mp_main.d \
./lib_src/ce1s_print_in_diff_formats_app.d \
./lib_src/mp_bin_str_printing.d \
./lib_src/mp_str_dec_number.d \
./lib_src/mp_uart_redirect.d 


# Each subdirectory must supply rules for building sources it contributes
lib_src/_mp_main.o: C:/proj_mp/ce1s_print_in_diff_formats/src/_mp_main.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/ce1s_print_in_diff_formats_app.o: C:/proj_mp/ce1s_print_in_diff_formats/src/ce1s_print_in_diff_formats_app.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/mp_bin_str_printing.o: C:/proj_mp/ce1s_print_in_diff_formats/lib/mp_bin_str_printing.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/mp_str_dec_number.o: C:/proj_mp/ce1s_print_in_diff_formats/lib/mp_str_dec_number.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lib_src/mp_uart_redirect.o: C:/proj_mp/ce1s_print_in_diff_formats/lib/mp_uart_redirect.c lib_src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F412Zx -c -I../../Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -I../../../lib -I../../../src -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lib_src

clean-lib_src:
	-$(RM) ./lib_src/_mp_main.cyclo ./lib_src/_mp_main.d ./lib_src/_mp_main.o ./lib_src/_mp_main.su ./lib_src/ce1s_print_in_diff_formats_app.cyclo ./lib_src/ce1s_print_in_diff_formats_app.d ./lib_src/ce1s_print_in_diff_formats_app.o ./lib_src/ce1s_print_in_diff_formats_app.su ./lib_src/mp_bin_str_printing.cyclo ./lib_src/mp_bin_str_printing.d ./lib_src/mp_bin_str_printing.o ./lib_src/mp_bin_str_printing.su ./lib_src/mp_str_dec_number.cyclo ./lib_src/mp_str_dec_number.d ./lib_src/mp_str_dec_number.o ./lib_src/mp_str_dec_number.su ./lib_src/mp_uart_redirect.cyclo ./lib_src/mp_uart_redirect.d ./lib_src/mp_uart_redirect.o ./lib_src/mp_uart_redirect.su

.PHONY: clean-lib_src

