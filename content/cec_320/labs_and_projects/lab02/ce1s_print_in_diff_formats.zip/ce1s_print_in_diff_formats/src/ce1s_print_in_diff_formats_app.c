#include <stdlib.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "mp_bin_str_printing.h"
#include "mp_str_dec_number.h"

void mp_app(void) {
	// \t does not seem to work in Renode so we use special formats oct nums
    char print_format1a[] = "%3d 0b%s  0%o 0x%X\n";
    char print_format1b[] = "%3d 0b%s 0%o 0x%X\n";
    char print_format2[] = "Your number: %3d \t %s \t 0x%02X\n";
    char dec_str[50];
    char bin_str[50];
    int dec_int = 0;
    int i = 0;

    printf("\n\nDemo project 'ce1s' starts here ---\n\n");

    printf("Print compact binary form via three different methods:\n");
    for (dec_int = 0; dec_int < 16; dec_int++) {
        mp_bin_print_num_in_cmpt_bin_choice(dec_int, 4, N2B_DIV_BY_2);
        printf("\t");
        mp_bin_print_num_in_cmpt_bin_choice(dec_int, 4, N2B_BIT_SCAN);
        printf("\t");
        mp_bin_print_num_in_cmpt_bin_choice(dec_int, 4, N2B_SHIFT2RT);
        printf("\n");
    }

    printf("\nPrint compact and verbose binary forms side-by-side:\n");
    for (dec_int = 16; dec_int < 32; dec_int++) {
        mp_bin_print_num_in_cmpt_bin(dec_int, 8);
        printf("\t");
        mp_bin_print_num_in_vrbs_bin_newln(dec_int, 8);
    }

    printf("\nPrint a table in four formats for each value:\n");
    for (dec_int = 0; dec_int < 8; dec_int++) {
        mp_bin_num_2_n_bit_cmpt_bin_str(bin_str, dec_int, 4);
        printf(print_format1a, dec_int, bin_str, dec_int, dec_int);
    }
    for (dec_int = 8; dec_int < 16; dec_int++) {
        mp_bin_num_2_n_bit_cmpt_bin_str(bin_str, dec_int, 4);
        printf(print_format1b, dec_int, bin_str, dec_int, dec_int);
    }
    printf("\n\n");

    SET_STDIN_TO_NO_BUFFER;
    while (1) {
        printf("Input the %dth 8-bit unsigned number in decimal: \n", i);
        scanf("%s", dec_str);
        if (mp_str_is_dec_int_num(dec_str)) {
            dec_int = atoi(dec_str);
            if (dec_int >= 0 && dec_int < 256) {
                mp_bin_num_2_n_bit_vrbs_bin_str(bin_str, dec_int, 8);
                printf(print_format2, dec_int, bin_str, dec_int);
                i++;
            } else {
                printf("Sorry, this is not a 8-bit unsigned number. ");
            }
        } else {
            printf("Sorry, this is not a decimal number. ");
        }
    }
}
